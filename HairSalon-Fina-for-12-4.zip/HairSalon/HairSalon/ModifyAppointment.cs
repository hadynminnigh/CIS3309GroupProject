﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{

    // also need all combo box choices for these
    // the same as book appointment
    public partial class ModifyAppointment : Form
    {
        DBManager db;
        public ModifyAppointment()
        {
            InitializeComponent();
            db = new DBManager();
        }

        

        private void comboBoxHairType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridViewStylistSchedules_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow selectedRow = dataGridViewStylistSchedules.Rows[e.RowIndex];

            
            comboBoxHairType.Text = selectedRow.Cells["HairType"].Value.ToString();
            comboBoxHairThickness.Text = selectedRow.Cells["HairThickness"].Value.ToString();
            comboBoxService.Text = selectedRow.Cells["Service"].Value.ToString();
            comboBoxStylist.Text = selectedRow.Cells["Stylist"].Value.ToString();

        }

        private void ModifyAppointment_Load(object sender, EventArgs e)
        {
            DataTable appointments = db.GetAppointments();
            dataGridViewStylistSchedules.DataSource = appointments;

        }


      
            private void buttonSaveChanges_Click(object sender, EventArgs e)
            {

            
        }
        private void LoadAppointments()
        {
            DataTable appointments = db.GetAppointments();
            dataGridViewStylistSchedules.DataSource = appointments;
            }

        private void buttonModify_Click(object sender, EventArgs e)
        {
            int rowIndex = dataGridViewStylistSchedules.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = dataGridViewStylistSchedules.Rows[rowIndex];

            string firstName = selectedRow.Cells["FirstName"].Value.ToString();
            string lastName = selectedRow.Cells["LastName"].Value.ToString();
            DateTime aptDate = Convert.ToDateTime(selectedRow.Cells["AptDate"].Value);

            string hairType = comboBoxHairType.Text;
            string hairThickness = comboBoxHairThickness.Text;
            string service = comboBoxService.SelectedItem.ToString();
            string stylist = comboBoxStylist.SelectedItem.ToString();

            
            db.UpdateAppointment(firstName, lastName, aptDate, hairType, hairThickness, service, stylist);

        }
    }

    }
    
 


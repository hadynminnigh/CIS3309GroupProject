﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{
    public partial class BookAppointment : Form
    {
        DBManager db;
        public BookAppointment()
        {
            InitializeComponent();
            db = new DBManager();
        }




        private void LoadStylists()
        {
       
            List<Stylist> stylists = db.GetStylists();

            
            dataGridViewStylistSchedules.DataSource = stylists;
        }

        private void BookAppointment_Load(object sender, EventArgs e)
        {
           

        }



        private void dateTimePickerAppointmentDate_ValueChanged(object sender, EventArgs e)
        {
            // Ensure the comboBoxStylist has a selected value
            if (comboBoxStylist.SelectedItem == null)
            {
                MessageBox.Show("Please select a stylist.");
                return; // Stop execution if no stylist is selected
            }

            string selectedStylist = comboBoxStylist.SelectedItem.ToString();
            DateTime selectedDate = dateTimePickerAppointmentDate.Value;

            // Check if stylist is available for the selected date
            bool isAvailable = db.IsStylistAvailableOnDate(selectedStylist, selectedDate);

            if (!isAvailable)
            {
                MessageBox.Show($"Sorry, {selectedStylist} is not available on {selectedDate.DayOfWeek}.");
            }
        }


        private void buttonBook_Click(object sender, EventArgs e)
        {
            // Retrieve form inputs
            string firstName = textBoxFirstName.Text;
            string lastName = textBoxLastName.Text;
            string email = textBoxEmail.Text;
            string phoneNumber = textBoxPhoneNumber.Text;
            string hairType = comboBoxHairType.Text;
            string thickness = comboBoxHairThickness.Text;
            string service = comboBoxService.Text;
            string stylist = comboBoxStylist.Text;
            DateTime aptDate = dateTimePickerAppointmentDate.Value;

            // Create an Appointment object
            Appointment book = new Appointment(firstName, lastName, email, phoneNumber, hairType, thickness, service, stylist, aptDate);


            db.BookAppointment(book);


            db.Update();


            MessageBox.Show("Appointment booked successfully!");


        }

        private void dataGridViewStylistSchedules_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void comboBoxService_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxService.SelectedItem == null) return;


            string selectedService = comboBoxService.SelectedItem.ToString();

            List<Stylist> stylists = db.GetStylistsByService(selectedService);



            dataGridViewStylistSchedules.DataSource = stylists;
        }

        private void BookAppointment_Load_1(object sender, EventArgs e)
        {
            dateTimePickerAppointmentDate.Format = DateTimePickerFormat.Custom;
            dateTimePickerAppointmentDate.CustomFormat = "dddd, MMMM dd, yyyy hh:mm tt";
        }

        private void comboBoxStylist_SelectedIndexChanged(object sender, EventArgs e)
        {
          
            }
        }
    }


 


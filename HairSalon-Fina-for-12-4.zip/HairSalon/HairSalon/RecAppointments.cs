﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{

    public partial class RecAppointments : Form
    {
        DBManager db;
        public RecAppointments()
        {
            InitializeComponent();
            db = new DBManager();

        }
        private void LoadAppointments()
        {
            DataTable appointments = db.GetAppointments();
            dataGridViewAppointments.DataSource = appointments;
        }



        private void buttonModify_Click(object sender, EventArgs e)
        {
            ModifyAppointment modifyAppointment = new ModifyAppointment();
            modifyAppointment.ShowDialog();
        }

        private void buttonBook_Click(object sender, EventArgs e)
        {
            BookAppointment bookAppointment = new BookAppointment();
            bookAppointment.ShowDialog();
        }

        private void RecAppointments_Load(object sender, EventArgs e)
        {
            LoadAppointments();
            
        }

        private void dataGridViewAppointments_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

     
            private void buttonCancel_Click(object sender, EventArgs e)
            {
          
              
                if (dataGridViewAppointments.SelectedRows.Count > 0)
                {
          
                    int rowIndex = dataGridViewAppointments.SelectedCells[0].RowIndex;
                    DataGridViewRow selectedRow = dataGridViewAppointments.Rows[rowIndex];

                    
                    string firstName = selectedRow.Cells["FirstName"].Value.ToString();
                    string lastName = selectedRow.Cells["LastName"].Value.ToString();
                    DateTime aptDate = Convert.ToDateTime(selectedRow.Cells["AptDate"].Value);

                   
                    db.CancelAppointment(firstName, lastName, aptDate);

                    LoadAppointments();
                }
                else
                {
                    MessageBox.Show("Please select an appointment to cancel.");
                }
            }


        }
    }



﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace HairSalon
{

    internal class DBManager
    {
        string connection = "Provider=Microsoft.ACE.OLEDB.12.0;" +
                                      "Data Source=HairSalonDB.accdb;";
        OleDbConnection myConnection;
        DataSet dataSet;
        DataSet StylistdataSet;
        OleDbDataAdapter dataAdapter;
        OleDbCommandBuilder commandBuilder;
        OleDbDataAdapter StylistdataAdapter;

        public DBManager()
        {
            myConnection = new OleDbConnection(connection);
            dataSet = new DataSet();

            dataAdapter = new OleDbDataAdapter("SELECT * FROM Appointments", myConnection);
            commandBuilder = new OleDbCommandBuilder(dataAdapter);
            dataAdapter.Fill(dataSet, "Appointments");
            myConnection = new OleDbConnection(connection);
            dataSet = new DataSet();

            dataAdapter = new OleDbDataAdapter("SELECT * FROM Appointments", myConnection);
            commandBuilder = new OleDbCommandBuilder(dataAdapter);
            dataAdapter.Fill(dataSet, "Appointments");


            LoadStylistsData();



        }
        public bool CheckLogin(string username, string password)
        {
            bool loginCorrect = false;

            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" +
                                      "Data Source=HairSalonDB.accdb;";

            string selectSql = "SELECT * FROM logins " +
                               "WHERE Username = '" + username + "' " +
                               "AND Password = '" + password + "'";

            OleDbConnection myConnection = new OleDbConnection(connectionString);
            OleDbCommand myCommand = new OleDbCommand(selectSql, myConnection);
            OleDbDataReader myDataReader;
            List<string> logins = new List<string>();

            try
            {
                myConnection.Open();
                myDataReader = myCommand.ExecuteReader();

                while (myDataReader.Read())
                {
                    string user = myDataReader["Username"].ToString();
                    logins.Add(user);
                }
            }
            catch (OleDbException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                myConnection.Close();
            }

            if (logins.Count == 0)
            {
                Console.WriteLine("Nothing was found " + logins);
            }
            else
            {
                loginCorrect = true;
            }

            return loginCorrect;
        }

        public string AccountType(string username, string password)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" +
                                      "Data Source=HairSalonDB.accdb;";

            string selectSql = "SELECT AccountType FROM logins " +
                               "WHERE Username = '" + username + "' " +
                               "AND Password = '" + password + "'";

            OleDbConnection myConnection = new OleDbConnection(connectionString);
            OleDbCommand myCommand = new OleDbCommand(selectSql, myConnection);
            OleDbDataReader myDataReader;
            List<string> accountType = new List<string>();

            try
            {
                myConnection.Open();
                myDataReader = myCommand.ExecuteReader();

                while (myDataReader.Read())
                {
                    string type = myDataReader["AccountType"].ToString();
                    accountType.Add(type);
                }
            }
            catch (OleDbException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                myConnection.Close();
            }

            if (accountType.Count == 0)
            {
                Console.WriteLine("Nothing was found " + accountType);
                return "Nothing was found";
            }
            else
            {
                return accountType[0];
            }


        }

        public DataTable GetAppointments()
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" +
                                      "Data Source=HairSalonDB.accdb;";

            string selectSql = "SELECT * FROM Appointments";

            OleDbConnection myConnection = new OleDbConnection(connectionString);
            //OleDbCommand myCommand = new OleDbCommand(selectSql, myConnection);
            OleDbDataAdapter myDataAdapter = new OleDbDataAdapter(selectSql, myConnection);
            DataTable appointmentTable = new DataTable();

            try
            {
                myConnection.Open();

                myDataAdapter.Fill(appointmentTable);
            }
            catch (OleDbException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                myConnection.Close();
            }

            return appointmentTable;
        }

        public void BookAppointment(Appointment appointment)
        {
            DataRow newRow = dataSet.Tables["Appointments"].NewRow();
            newRow["FirstName"] = appointment.FirstName;
            newRow["LastName"] = appointment.LastName;
            newRow["Email"] = appointment.Email;
            newRow["Phonenumber"] = appointment.Phonenumber;
            newRow["Hairtype"] = appointment.Hairtype;
            newRow["HairThickness"] = appointment.Thickness;
            newRow["Service"] = appointment.Service;
            newRow["Stylist"] = appointment.Stylist;
            newRow["Aptdate"] = appointment.AptDate;

            dataSet.Tables["Appointments"].Rows.Add(newRow);
            dataAdapter.InsertCommand = commandBuilder.GetInsertCommand();
            Update();
        }

        public void Update()
        {
            myConnection.Open();
            dataAdapter.Update(dataSet, "Appointments");
            myConnection.Close();
        }
        public void DeleteAppointment(Appointment appointment)
        {
            //will add this eventually but i wanna do the stylist stuff first
        }
        public void LoadStylistsData()
        {
            string selectSql = "SELECT * FROM Stylists";

            OleDbDataAdapter stylistAdapter = new OleDbDataAdapter(selectSql, myConnection);
            stylistAdapter.Fill(dataSet, "Stylists");
        }

        public List<Stylist> GetStylists()
        {
            List<Stylist> stylists = new List<Stylist>();
            foreach (DataRow row in dataSet.Tables["Stylists"].Rows)
            {
                Stylist stylist = new Stylist(
                    row["StylistName"].ToString(),
                    Convert.ToBoolean(row["MWF"]),
                    Convert.ToBoolean(row["TuTh"]),
                    Convert.ToBoolean(row["Cut"]),
                    Convert.ToBoolean(row["CutandWash"]),
                    Convert.ToBoolean(row["Extensions"]),
                    Convert.ToBoolean(row["Highlights"]),
                    Convert.ToBoolean(row["Balayage"]),
                    Convert.ToBoolean(row["TouchUp"]),
                    Convert.ToBoolean(row["Perm"]),
                    Convert.ToBoolean(row["BlowOut"]),
                    Convert.ToBoolean(row["CurlyCut"]),
                    Convert.ToBoolean(row["FullColor"]),
                    Convert.ToBoolean(row["ColorConsultation"]),
                    Convert.ToInt32(row["EmployeeID"])
                );
                stylists.Add(stylist);
            }
            return stylists;
        }
        public List<Stylist> GetStylistsByService(string serviceName)
        {
            List<Stylist> stylists = new List<Stylist>();

            foreach (DataRow row in dataSet.Tables["Stylists"].Rows)
            {
              
                if (Convert.ToBoolean(row[serviceName]))
                {
                    Stylist stylist = new Stylist(
                        row["StylistName"].ToString(),
                        Convert.ToBoolean(row["MWF"]),
                        Convert.ToBoolean(row["TuTh"]),
                        Convert.ToBoolean(row["Cut"]),
                        Convert.ToBoolean(row["CutandWash"]),
                        Convert.ToBoolean(row["Extensions"]),
                        Convert.ToBoolean(row["Highlights"]),
                        Convert.ToBoolean(row["Balayage"]),
                        Convert.ToBoolean(row["TouchUp"]),
                        Convert.ToBoolean(row["Perm"]),
                        Convert.ToBoolean(row["BlowOut"]),
                        Convert.ToBoolean(row["CurlyCut"]),
                        Convert.ToBoolean(row["FullColor"]),
                        Convert.ToBoolean(row["ColorConsultation"]),
                        Convert.ToInt32(row["EmployeeID"])
                    );
                    stylists.Add(stylist);
                }
            }

            return stylists;
        }
        public List<Stylist> GetStylistsByDate(string Date)
        {
            List<Stylist> stylists = new List<Stylist>();

            foreach (DataRow row in dataSet.Tables["Stylists"].Rows)
            {

                if (Convert.ToBoolean(row[Date]))
                {
                    Stylist stylist = new Stylist(
                        row["StylistName"].ToString(),
                        Convert.ToBoolean(row["MWF"]),
                        Convert.ToBoolean(row["TuTh"]),
                        Convert.ToBoolean(row["Cut"]),
                        Convert.ToBoolean(row["CutandWash"]),
                        Convert.ToBoolean(row["Extensions"]),
                        Convert.ToBoolean(row["Highlights"]),
                        Convert.ToBoolean(row["Balayage"]),
                        Convert.ToBoolean(row["TouchUp"]),
                        Convert.ToBoolean(row["Perm"]),
                        Convert.ToBoolean(row["BlowOut"]),
                        Convert.ToBoolean(row["CurlyCut"]),
                        Convert.ToBoolean(row["FullColor"]),
                        Convert.ToBoolean(row["ColorConsultation"]),
                        Convert.ToInt32(row["EmployeeID"])
                    );
                    stylists.Add(stylist);
                }
            }

            return stylists;
        }
        public bool IsStylistAvailableOnDate(string stylistName, DateTime selectedDate)
        {
            string dayOfWeek = selectedDate.DayOfWeek.ToString(); 

            foreach (DataRow row in dataSet.Tables["Stylists"].Rows)
            {
                if (row["StylistName"].ToString() == stylistName)
                {
                    // Check if the stylist is available on the selected day
                    if (dayOfWeek == "Monday" || dayOfWeek == "Wednesday" || dayOfWeek == "Friday")
                    {
                        
                        return Convert.ToBoolean(row["MWF"]);
                    }
                    else if (dayOfWeek == "Tuesday" || dayOfWeek == "Thursday")
                    {
                        
                        return Convert.ToBoolean(row["TuTh"]);
                    }
                }
            }
            return false; 
        }
        public void UpdateAppointment(string hairType, string hairThickness, string service, string stylist)
        {
            if (myConnection.State == ConnectionState.Closed)
            {
                myConnection.Open();
            }

            string query = "UPDATE Appointments SET HairType = @HairType, HairThickness = @HairThickness, Service = @Service, Stylist = @Stylist WHERE AppointmentID = @AppointmentID";

            OleDbCommand command = new OleDbCommand(query, myConnection);
            command.Parameters.AddWithValue("@HairType", hairType);
            command.Parameters.AddWithValue("@HairThickness", hairThickness);
            command.Parameters.AddWithValue("@Service", service);
            command.Parameters.AddWithValue("@Stylist", stylist);
           

            try
            {
                command.ExecuteNonQuery();
                MessageBox.Show("Appointment updated successfully!");
            }
            catch (OleDbException ex)
            {
                MessageBox.Show($"Error updating appointment: {ex.Message}");
            }
            finally
            {
                myConnection.Close();
            }
        }

    }

}






﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{
    public partial class StylistViewMenu : Form
    {
        public StylistViewMenu()
        {
            InitializeComponent();
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            
            StylistViewAppointment viewAppointments = new StylistViewAppointment();
            viewAppointments.ShowDialog();
        }

        private void btnViewSchedule_Click(object sender, EventArgs e)
        {
            StylistViewSchedules viewSchedules = new StylistViewSchedules();
            viewSchedules.ShowDialog();
        }

        private void btnSearchProducts_Click(object sender, EventArgs e)
        {
            Products products = new Products();
            products.ShowDialog();
        }

        private void btnPayment_Click(object sender, EventArgs e)
        {
            Checkout checkout = new Checkout();
            checkout.ShowDialog();
        }
    }
}

﻿namespace HairSalon
{
    partial class RecViewMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBook = new System.Windows.Forms.Button();
            this.btnViewSchedule = new System.Windows.Forms.Button();
            this.btnSearchProducts = new System.Windows.Forms.Button();
            this.btnPayment = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnBook
            // 
            this.btnBook.Location = new System.Drawing.Point(298, 437);
            this.btnBook.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.btnBook.Name = "btnBook";
            this.btnBook.Size = new System.Drawing.Size(363, 126);
            this.btnBook.TabIndex = 0;
            this.btnBook.Text = "View Appointments";
            this.btnBook.UseVisualStyleBackColor = true;
            this.btnBook.Click += new System.EventHandler(this.btnBook_Click);
            // 
            // btnViewSchedule
            // 
            this.btnViewSchedule.Location = new System.Drawing.Point(677, 443);
            this.btnViewSchedule.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.btnViewSchedule.Name = "btnViewSchedule";
            this.btnViewSchedule.Size = new System.Drawing.Size(363, 114);
            this.btnViewSchedule.TabIndex = 4;
            this.btnViewSchedule.Text = "View Schedule";
            this.btnViewSchedule.UseVisualStyleBackColor = true;
            this.btnViewSchedule.Click += new System.EventHandler(this.btnViewSchedule_Click);
            // 
            // btnSearchProducts
            // 
            this.btnSearchProducts.Location = new System.Drawing.Point(1056, 443);
            this.btnSearchProducts.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.btnSearchProducts.Name = "btnSearchProducts";
            this.btnSearchProducts.Size = new System.Drawing.Size(363, 114);
            this.btnSearchProducts.TabIndex = 5;
            this.btnSearchProducts.Text = "Search Products";
            this.btnSearchProducts.UseVisualStyleBackColor = true;
            this.btnSearchProducts.Click += new System.EventHandler(this.btnSearchProducts_Click);
            // 
            // btnPayment
            // 
            this.btnPayment.Location = new System.Drawing.Point(1435, 443);
            this.btnPayment.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.btnPayment.Name = "btnPayment";
            this.btnPayment.Size = new System.Drawing.Size(355, 114);
            this.btnPayment.TabIndex = 6;
            this.btnPayment.Text = "Make Payment";
            this.btnPayment.UseVisualStyleBackColor = true;
            this.btnPayment.Click += new System.EventHandler(this.btnPayment_Click);
            // 
            // RecViewMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2133, 1073);
            this.Controls.Add(this.btnPayment);
            this.Controls.Add(this.btnSearchProducts);
            this.Controls.Add(this.btnViewSchedule);
            this.Controls.Add(this.btnBook);
            this.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.Name = "RecViewMenu";
            this.Text = "Pick Action";
            this.Load += new System.EventHandler(this.frHomepage_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnBook;
        private System.Windows.Forms.Button btnViewSchedule;
        private System.Windows.Forms.Button btnSearchProducts;
        private System.Windows.Forms.Button btnPayment;
    }
}


﻿namespace HairSalon
{
    partial class RecViewAppointment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewAppointments = new System.Windows.Forms.DataGridView();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnBookApt = new System.Windows.Forms.Button();
            this.btnModifyApt = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAppointments)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewAppointments
            // 
            this.dataGridViewAppointments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAppointments.Location = new System.Drawing.Point(81, 60);
            this.dataGridViewAppointments.Name = "dataGridViewAppointments";
            this.dataGridViewAppointments.RowHeadersWidth = 102;
            this.dataGridViewAppointments.RowTemplate.Height = 40;
            this.dataGridViewAppointments.Size = new System.Drawing.Size(1231, 494);
            this.dataGridViewAppointments.TabIndex = 0;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(545, 673);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(357, 126);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "Cancel Appoitment";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnBookApt
            // 
            this.btnBookApt.Location = new System.Drawing.Point(166, 672);
            this.btnBookApt.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.btnBookApt.Name = "btnBookApt";
            this.btnBookApt.Size = new System.Drawing.Size(363, 129);
            this.btnBookApt.TabIndex = 3;
            this.btnBookApt.Text = "Book Appointment";
            this.btnBookApt.UseVisualStyleBackColor = true;
            this.btnBookApt.Click += new System.EventHandler(this.btnBookApt_Click);
            // 
            // btnModifyApt
            // 
            this.btnModifyApt.Location = new System.Drawing.Point(918, 672);
            this.btnModifyApt.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.btnModifyApt.Name = "btnModifyApt";
            this.btnModifyApt.Size = new System.Drawing.Size(363, 129);
            this.btnModifyApt.TabIndex = 4;
            this.btnModifyApt.Text = "Modify Apoitments";
            this.btnModifyApt.UseVisualStyleBackColor = true;
            this.btnModifyApt.Click += new System.EventHandler(this.btnModifyApt_Click);
            // 
            // ViewAppointments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1398, 955);
            this.Controls.Add(this.btnModifyApt);
            this.Controls.Add(this.btnBookApt);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.dataGridViewAppointments);
            this.Name = "ViewAppointments";
            this.Text = "ViewAppointments";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAppointments)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewAppointments;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnBookApt;
        private System.Windows.Forms.Button btnModifyApt;
    }
}
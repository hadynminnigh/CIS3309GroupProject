﻿namespace HairSalon
{
    partial class BookAppointment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxCustomerInfo = new System.Windows.Forms.GroupBox();
            this.cboStylist = new System.Windows.Forms.ComboBox();
            this.lblStylistSelect = new System.Windows.Forms.Label();
            this.cboService = new System.Windows.Forms.ComboBox();
            this.cboThickness = new System.Windows.Forms.ComboBox();
            this.cboHairType = new System.Windows.Forms.ComboBox();
            this.txtPhoneNumber = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.lblThickness = new System.Windows.Forms.Label();
            this.lblService = new System.Windows.Forms.Label();
            this.lblHairType = new System.Windows.Forms.Label();
            this.lblPhoneNumber = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.groupBoxPossibleApt = new System.Windows.Forms.GroupBox();
            this.dataGridViewBookApts = new System.Windows.Forms.DataGridView();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.btnBookAppoitment = new System.Windows.Forms.Button();
            this.groupBoxCustomerInfo.SuspendLayout();
            this.groupBoxPossibleApt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBookApts)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxCustomerInfo
            // 
            this.groupBoxCustomerInfo.Controls.Add(this.cboStylist);
            this.groupBoxCustomerInfo.Controls.Add(this.lblStylistSelect);
            this.groupBoxCustomerInfo.Controls.Add(this.cboService);
            this.groupBoxCustomerInfo.Controls.Add(this.cboThickness);
            this.groupBoxCustomerInfo.Controls.Add(this.cboHairType);
            this.groupBoxCustomerInfo.Controls.Add(this.txtPhoneNumber);
            this.groupBoxCustomerInfo.Controls.Add(this.txtEmail);
            this.groupBoxCustomerInfo.Controls.Add(this.txtLastName);
            this.groupBoxCustomerInfo.Controls.Add(this.txtFirstName);
            this.groupBoxCustomerInfo.Controls.Add(this.lblThickness);
            this.groupBoxCustomerInfo.Controls.Add(this.lblService);
            this.groupBoxCustomerInfo.Controls.Add(this.lblHairType);
            this.groupBoxCustomerInfo.Controls.Add(this.lblPhoneNumber);
            this.groupBoxCustomerInfo.Controls.Add(this.lblEmail);
            this.groupBoxCustomerInfo.Controls.Add(this.lblLastName);
            this.groupBoxCustomerInfo.Controls.Add(this.lblFirstName);
            this.groupBoxCustomerInfo.Location = new System.Drawing.Point(35, 31);
            this.groupBoxCustomerInfo.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.groupBoxCustomerInfo.Name = "groupBoxCustomerInfo";
            this.groupBoxCustomerInfo.Padding = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.groupBoxCustomerInfo.Size = new System.Drawing.Size(915, 889);
            this.groupBoxCustomerInfo.TabIndex = 0;
            this.groupBoxCustomerInfo.TabStop = false;
            this.groupBoxCustomerInfo.Text = "Customer Info";
            // 
            // cboStylist
            // 
            this.cboStylist.FormattingEnabled = true;
            this.cboStylist.Items.AddRange(new object[] {
            "Any",
            "Martha"});
            this.cboStylist.Location = new System.Drawing.Point(16, 692);
            this.cboStylist.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.cboStylist.Name = "cboStylist";
            this.cboStylist.Size = new System.Drawing.Size(316, 39);
            this.cboStylist.TabIndex = 23;
            // 
            // lblStylistSelect
            // 
            this.lblStylistSelect.AutoSize = true;
            this.lblStylistSelect.Location = new System.Drawing.Point(19, 653);
            this.lblStylistSelect.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblStylistSelect.Name = "lblStylistSelect";
            this.lblStylistSelect.Size = new System.Drawing.Size(99, 32);
            this.lblStylistSelect.TabIndex = 22;
            this.lblStylistSelect.Text = "Stylist:";
            // 
            // cboService
            // 
            this.cboService.FormattingEnabled = true;
            this.cboService.Items.AddRange(new object[] {
            "Cut ",
            "Cut and Wash(includdes vlow dry)",
            "Curly Cut",
            "Blowout",
            "Perm",
            "Blow Out",
            "Highlighs",
            "Balayage",
            "Touch Up",
            "Full Color",
            "Color Consultation",
            "Extensions"});
            this.cboService.Location = new System.Drawing.Point(16, 596);
            this.cboService.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.cboService.Name = "cboService";
            this.cboService.Size = new System.Drawing.Size(316, 39);
            this.cboService.TabIndex = 21;
            // 
            // cboThickness
            // 
            this.cboThickness.FormattingEnabled = true;
            this.cboThickness.Items.AddRange(new object[] {
            "Thin",
            "Medium",
            "Thick"});
            this.cboThickness.Location = new System.Drawing.Point(16, 501);
            this.cboThickness.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.cboThickness.Name = "cboThickness";
            this.cboThickness.Size = new System.Drawing.Size(316, 39);
            this.cboThickness.TabIndex = 20;
            // 
            // cboHairType
            // 
            this.cboHairType.FormattingEnabled = true;
            this.cboHairType.Items.AddRange(new object[] {
            "Straight",
            "Curly",
            "Wavy"});
            this.cboHairType.Location = new System.Drawing.Point(16, 384);
            this.cboHairType.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.cboHairType.Name = "cboHairType";
            this.cboHairType.Size = new System.Drawing.Size(316, 39);
            this.cboHairType.TabIndex = 17;
            // 
            // txtPhoneNumber
            // 
            this.txtPhoneNumber.Location = new System.Drawing.Point(248, 277);
            this.txtPhoneNumber.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtPhoneNumber.Name = "txtPhoneNumber";
            this.txtPhoneNumber.Size = new System.Drawing.Size(260, 38);
            this.txtPhoneNumber.TabIndex = 16;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(128, 207);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(260, 38);
            this.txtEmail.TabIndex = 15;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(195, 141);
            this.txtLastName.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(260, 38);
            this.txtLastName.TabIndex = 14;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(195, 79);
            this.txtFirstName.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(260, 38);
            this.txtFirstName.TabIndex = 13;
            // 
            // lblThickness
            // 
            this.lblThickness.AutoSize = true;
            this.lblThickness.Location = new System.Drawing.Point(16, 463);
            this.lblThickness.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblThickness.Name = "lblThickness";
            this.lblThickness.Size = new System.Drawing.Size(209, 32);
            this.lblThickness.TabIndex = 11;
            this.lblThickness.Text = "Hair Thickness:";
            // 
            // lblService
            // 
            this.lblService.AutoSize = true;
            this.lblService.Location = new System.Drawing.Point(19, 558);
            this.lblService.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblService.Name = "lblService";
            this.lblService.Size = new System.Drawing.Size(117, 32);
            this.lblService.TabIndex = 5;
            this.lblService.Text = "Service:";
            this.lblService.Click += new System.EventHandler(this.lblService_Click);
            // 
            // lblHairType
            // 
            this.lblHairType.AutoSize = true;
            this.lblHairType.Location = new System.Drawing.Point(16, 346);
            this.lblHairType.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblHairType.Name = "lblHairType";
            this.lblHairType.Size = new System.Drawing.Size(144, 32);
            this.lblHairType.TabIndex = 4;
            this.lblHairType.Text = "Hair Type:";
            // 
            // lblPhoneNumber
            // 
            this.lblPhoneNumber.AutoSize = true;
            this.lblPhoneNumber.Location = new System.Drawing.Point(16, 284);
            this.lblPhoneNumber.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblPhoneNumber.Name = "lblPhoneNumber";
            this.lblPhoneNumber.Size = new System.Drawing.Size(212, 32);
            this.lblPhoneNumber.TabIndex = 3;
            this.lblPhoneNumber.Text = "Phone Number:";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(19, 215);
            this.lblEmail.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(94, 32);
            this.lblEmail.TabIndex = 2;
            this.lblEmail.Text = "Email:";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(16, 148);
            this.lblLastName.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(158, 32);
            this.lblLastName.TabIndex = 1;
            this.lblLastName.Text = "Last Name:";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(19, 88);
            this.lblFirstName.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(159, 32);
            this.lblFirstName.TabIndex = 0;
            this.lblFirstName.Text = "First Name:";
            // 
            // groupBoxPossibleApt
            // 
            this.groupBoxPossibleApt.Controls.Add(this.dataGridViewBookApts);
            this.groupBoxPossibleApt.Location = new System.Drawing.Point(995, 31);
            this.groupBoxPossibleApt.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.groupBoxPossibleApt.Name = "groupBoxPossibleApt";
            this.groupBoxPossibleApt.Padding = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.groupBoxPossibleApt.Size = new System.Drawing.Size(1107, 739);
            this.groupBoxPossibleApt.TabIndex = 1;
            this.groupBoxPossibleApt.TabStop = false;
            this.groupBoxPossibleApt.Text = "Possible Appoitments";
            // 
            // dataGridViewBookApts
            // 
            this.dataGridViewBookApts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBookApts.Location = new System.Drawing.Point(45, 48);
            this.dataGridViewBookApts.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.dataGridViewBookApts.Name = "dataGridViewBookApts";
            this.dataGridViewBookApts.RowHeadersWidth = 102;
            this.dataGridViewBookApts.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewBookApts.Size = new System.Drawing.Size(1045, 663);
            this.dataGridViewBookApts.TabIndex = 0;
            // 
            // btnBookAppoitment
            // 
            this.btnBookAppoitment.Location = new System.Drawing.Point(1273, 784);
            this.btnBookAppoitment.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.btnBookAppoitment.Name = "btnBookAppoitment";
            this.btnBookAppoitment.Size = new System.Drawing.Size(573, 153);
            this.btnBookAppoitment.TabIndex = 3;
            this.btnBookAppoitment.Text = "Book Appoitment";
            this.btnBookAppoitment.UseVisualStyleBackColor = true;
            this.btnBookAppoitment.Click += new System.EventHandler(this.btnBookAppoitment_Click_1);
            // 
            // BookAppointment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2133, 1073);
            this.Controls.Add(this.btnBookAppoitment);
            this.Controls.Add(this.groupBoxPossibleApt);
            this.Controls.Add(this.groupBoxCustomerInfo);
            this.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.Name = "BookAppointment";
            this.Text = "BookAppointment";
            this.Load += new System.EventHandler(this.BookAppointment_Load);
            this.groupBoxCustomerInfo.ResumeLayout(false);
            this.groupBoxCustomerInfo.PerformLayout();
            this.groupBoxPossibleApt.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBookApts)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxCustomerInfo;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblService;
        private System.Windows.Forms.Label lblHairType;
        private System.Windows.Forms.Label lblPhoneNumber;
        private System.Windows.Forms.ComboBox cboHairType;
        private System.Windows.Forms.TextBox txtPhoneNumber;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label lblThickness;
        private System.Windows.Forms.ComboBox cboService;
        private System.Windows.Forms.ComboBox cboThickness;
        private System.Windows.Forms.GroupBox groupBoxPossibleApt;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.DataGridView dataGridViewBookApts;
        private System.Windows.Forms.ComboBox cboStylist;
        private System.Windows.Forms.Label lblStylistSelect;
        private System.Windows.Forms.Button btnBookAppoitment;
    }
}
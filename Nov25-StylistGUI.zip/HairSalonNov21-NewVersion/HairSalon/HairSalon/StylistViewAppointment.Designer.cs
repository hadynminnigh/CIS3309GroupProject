﻿namespace HairSalon
{
    partial class StylistViewAppointment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnModifyApt = new System.Windows.Forms.Button();
            this.btnBookApt = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.dataGridViewAppointments = new System.Windows.Forms.DataGridView();
            this.buttonFilterAppointments = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAppointments)).BeginInit();
            this.SuspendLayout();
            // 
            // btnModifyApt
            // 
            this.btnModifyApt.Location = new System.Drawing.Point(1005, 714);
            this.btnModifyApt.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.btnModifyApt.Name = "btnModifyApt";
            this.btnModifyApt.Size = new System.Drawing.Size(363, 129);
            this.btnModifyApt.TabIndex = 8;
            this.btnModifyApt.Text = "Modify Apoitments";
            this.btnModifyApt.UseVisualStyleBackColor = true;
            this.btnModifyApt.Click += new System.EventHandler(this.btnModifyApt_Click);
            // 
            // btnBookApt
            // 
            this.btnBookApt.Location = new System.Drawing.Point(253, 714);
            this.btnBookApt.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.btnBookApt.Name = "btnBookApt";
            this.btnBookApt.Size = new System.Drawing.Size(363, 129);
            this.btnBookApt.TabIndex = 7;
            this.btnBookApt.Text = "Book Appointment";
            this.btnBookApt.UseVisualStyleBackColor = true;
            this.btnBookApt.Click += new System.EventHandler(this.btnBookApt_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(632, 715);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(357, 126);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "Cancel Appoitment";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // dataGridViewAppointments
            // 
            this.dataGridViewAppointments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAppointments.Location = new System.Drawing.Point(168, 102);
            this.dataGridViewAppointments.Name = "dataGridViewAppointments";
            this.dataGridViewAppointments.RowHeadersWidth = 102;
            this.dataGridViewAppointments.RowTemplate.Height = 40;
            this.dataGridViewAppointments.Size = new System.Drawing.Size(1231, 494);
            this.dataGridViewAppointments.TabIndex = 5;
            // 
            // buttonFilterAppointments
            // 
            this.buttonFilterAppointments.Location = new System.Drawing.Point(589, 884);
            this.buttonFilterAppointments.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.buttonFilterAppointments.Name = "buttonFilterAppointments";
            this.buttonFilterAppointments.Size = new System.Drawing.Size(438, 126);
            this.buttonFilterAppointments.TabIndex = 9;
            this.buttonFilterAppointments.Text = "My Appointments";
            this.buttonFilterAppointments.UseVisualStyleBackColor = true;
            this.buttonFilterAppointments.Click += new System.EventHandler(this.buttonFilterAppointments_Click);
            // 
            // StylistViewAppointment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1633, 1132);
            this.Controls.Add(this.buttonFilterAppointments);
            this.Controls.Add(this.btnModifyApt);
            this.Controls.Add(this.btnBookApt);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.dataGridViewAppointments);
            this.Name = "StylistViewAppointment";
            this.Text = "StylistViewAppointment";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAppointments)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnModifyApt;
        private System.Windows.Forms.Button btnBookApt;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.DataGridView dataGridViewAppointments;
        private System.Windows.Forms.Button buttonFilterAppointments;
    }
}
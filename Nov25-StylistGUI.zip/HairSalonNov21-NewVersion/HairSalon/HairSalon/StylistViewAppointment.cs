﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{
    public partial class StylistViewAppointment : Form
    {
        public StylistViewAppointment()
        {
            InitializeComponent();
        }

        private void btnBookApt_Click(object sender, EventArgs e)
        {
            BookAppointment bookAppointment = new BookAppointment();
            bookAppointment.ShowDialog();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            // same as receptionist
        }

        private void btnModifyApt_Click(object sender, EventArgs e)
        {
            ModifyAppointment modifyAppointment = new ModifyAppointment();
            modifyAppointment.ShowDialog();
        }

        private void buttonFilterAppointments_Click(object sender, EventArgs e)
        {
            // this will just filter what's shown in the datagridview to just the stylists appointments
        }
    }
}

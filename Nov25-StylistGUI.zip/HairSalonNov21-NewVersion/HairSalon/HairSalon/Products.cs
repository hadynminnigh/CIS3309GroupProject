﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{

    // NOT PART OF SPECIFIC VIEW BECAUSE IT CAN BE REUSED
    public partial class Products : Form
    {
        public Products()
        {
            InitializeComponent();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            // goes back to menu
        }

        private void buttonReserve_Click(object sender, EventArgs e)
        {
            // instead of adding a product to an appointment
            // we can just reduce the amount in stock by one
            // each time this button is clicked
        }
    }
}

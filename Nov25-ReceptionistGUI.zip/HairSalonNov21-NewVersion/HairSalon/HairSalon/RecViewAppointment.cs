﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{
    public partial class RecViewAppointment : Form
    {
        public RecViewAppointment()
        {
            InitializeComponent();
        }

        private void btnBookApt_Click(object sender, EventArgs e)
        {
            BookAppointment bookAppointment = new BookAppointment();
            bookAppointment.ShowDialog();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            // if appointment is within 24 hours bring up payment form and message box saying they owe money
            // else delete the record

            // if record doesnt exist anymore ....
            MessageBox.Show("Your appointment has been successfully cancelled!");
            // else show messagebox saying something went wrong
        }

        private void btnModifyApt_Click(object sender, EventArgs e)
        {
            // basically looks the same as book appointment except it overwrites the appointment
        }
    }
}

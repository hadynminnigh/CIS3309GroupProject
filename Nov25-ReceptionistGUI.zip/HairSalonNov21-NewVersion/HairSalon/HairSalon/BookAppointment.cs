﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace HairSalon
{

    // NOT PART OF SPECIFIC VIEW BECAUSE IT CAN BE REUSED
    public partial class BookAppointment : Form
    {

        private dbManage db;
        public BookAppointment()
        {
            InitializeComponent();
            db = new dbManage();
        }

        private void lblService_Click(object sender, EventArgs e)
        {
            
        }

        private void BookAppointment_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnBookAppoitment_Click(object sender, EventArgs e)
        {
           
        }

        private void btnBookAppoitment_Click_1(object sender, EventArgs e)
        {
            string firstname = txtFirstName.Text;
            string lastname = txtLastName.Text;
            string email = txtEmail.Text;
            string phoneNumber = txtPhoneNumber.Text;
            string hairType = cboHairType.Text;
            string thickness = cboThickness.Text;
            string service = cboService.Text;
            string stylist = cboStylist.Text;


            Appointment book = new Appointment(firstname, lastname, email, phoneNumber, hairType, thickness, service, stylist);

            db.BookAppointment(book);

            db.Update();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairSalon
{
    public class Appointment
    {
        private string customerName;
        private string email;
        private string phonenumber;
        private string hairtype;
        private string thickness;
        private string service;
        private string stylistName;
        private DateTime date; //format is DateTime(year,month,day,hour,minute,second)
        private int cardInfo;

        public string CustomerName
        {
            get { return customerName; }
            set { customerName = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        public string Phonenumber
        {
            get { return phonenumber; }
            set { phonenumber = value; }
        }

        public string Hairtype
        {
            get { return hairtype; }
            set { hairtype = value; }
        }

        public string Thickness
        {
            get { return thickness; }
            set { thickness = value; }
        }

        public string Service
        {
            get { return service; }
            set { service = value; }
        }
        
        public string StylistName
        {
            get { return stylistName; }
            set { stylistName = value; }
        }
        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }
        public int CardInfo
        {
            get { return cardInfo; }
            set { cardInfo = value; }
        }
        

        public Appointment(string customerName, string email, string phonenumber, string hairtype, string thickness, string service, string stylistName, DateTime date, int cardInfo)
        {
            this.customerName = customerName;
            this.email = email;
            this.phonenumber = phonenumber;
            this.hairtype = hairtype;
            this.thickness = thickness;
            this.service = service;
            this.stylistName = stylistName;
            this.date = date;
            this.cardInfo = cardInfo;
        }

        public override string ToString()
        {
            return $"{CustomerName},{Email},{Phonenumber},{Hairtype},{Thickness},{Service},{StylistName},{Date},{CardInfo}";
        }

        public static class BookAppointments
        {
            public static List<Appointment> AppointmentsBooked = new List<Appointment>();
        }
    }
}

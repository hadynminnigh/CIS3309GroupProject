﻿namespace HairSalon
{
    partial class RecViewSchedules
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.labelStylistName = new System.Windows.Forms.Label();
            this.comboBoxStylistName = new System.Windows.Forms.ComboBox();
            this.labelFilter = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(119, 62);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 102;
            this.dataGridView1.RowTemplate.Height = 40;
            this.dataGridView1.Size = new System.Drawing.Size(1241, 421);
            this.dataGridView1.TabIndex = 0;
            // 
            // labelStylistName
            // 
            this.labelStylistName.AutoSize = true;
            this.labelStylistName.Location = new System.Drawing.Point(390, 643);
            this.labelStylistName.Name = "labelStylistName";
            this.labelStylistName.Size = new System.Drawing.Size(188, 32);
            this.labelStylistName.TabIndex = 1;
            this.labelStylistName.Text = "Stylist Name: ";
            // 
            // comboBoxStylistName
            // 
            this.comboBoxStylistName.FormattingEnabled = true;
            this.comboBoxStylistName.Location = new System.Drawing.Point(584, 640);
            this.comboBoxStylistName.Name = "comboBoxStylistName";
            this.comboBoxStylistName.Size = new System.Drawing.Size(403, 39);
            this.comboBoxStylistName.TabIndex = 3;
            // 
            // labelFilter
            // 
            this.labelFilter.AutoSize = true;
            this.labelFilter.Location = new System.Drawing.Point(649, 563);
            this.labelFilter.Name = "labelFilter";
            this.labelFilter.Size = new System.Drawing.Size(78, 32);
            this.labelFilter.TabIndex = 4;
            this.labelFilter.Text = "Filter";
            // 
            // Schedules
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1489, 828);
            this.Controls.Add(this.labelFilter);
            this.Controls.Add(this.comboBoxStylistName);
            this.Controls.Add(this.labelStylistName);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Schedules";
            this.Text = "Schedules";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label labelStylistName;
        private System.Windows.Forms.ComboBox comboBoxStylistName;
        private System.Windows.Forms.Label labelFilter;
    }
}
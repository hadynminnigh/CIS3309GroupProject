﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{
    public partial class RecViewMenu : Form
    {
        public RecViewMenu()
        {
            InitializeComponent();
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            BookAppointment viewAppointments = new BookAppointment();
            viewAppointments.ShowDialog();



        }

        private void frHomepage_Load(object sender, EventArgs e)
        {
            
        }

        private void btnViewSchedule_Click(object sender, EventArgs e)
        {
            RecViewSchedules viewSchedules = new RecViewSchedules();
            viewSchedules.ShowDialog();
        }

        private void btnSearchProducts_Click(object sender, EventArgs e)
        {
            Products searchProducts = new Products();
            searchProducts.ShowDialog();
        }

        private void btnPayment_Click(object sender, EventArgs e)
        {
            Checkout payment = new Checkout();
            payment.ShowDialog();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{

    // NOT PART OF SPECIFIC VIEW BECAUSE IT CAN BE REUSED
    public partial class Checkout : Form
    {
        public Checkout()
        {
            InitializeComponent();
        }
    }
}

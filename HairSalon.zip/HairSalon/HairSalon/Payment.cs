﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{
    public partial class Payment : Form
    {

        DBManager db;
        public Payment()
        {
            InitializeComponent();
            db = new DBManager();
        }

        private void buttonPayment_Click(object sender, EventArgs e)
        {
            if (textBoxCardInfo.Text == "")
            {
                MessageBox.Show("Please input your card details.");
            }
            if (textBoxAddress.Text == "")
            {
                MessageBox.Show("Please input your address.");
            }
            else
            {
                if (dataGridViewAppointments.SelectedRows.Count == 1)
                {

                    int rowIndex = dataGridViewAppointments.SelectedCells[0].RowIndex;
                    DataGridViewRow selectedRow = dataGridViewAppointments.Rows[rowIndex];

                    // if statement that checks if the value of the first two cells in the selected row are equal to the name input into the full name textbox
                    string rowFirstName = selectedRow.Cells[0].Value.ToString();
                    string rowLastName = selectedRow.Cells[1].Value.ToString();
                    string rowFullName = rowFirstName + " " + rowLastName;
                    string fullName = textBoxFullName.Text;

                    if (fullName == rowFullName)
                    {
                        db.AppointmentPayment(rowFirstName, rowLastName);
                        MessageBox.Show("Your payment has been confirmed!");
                    }
                    else
                    {
                        MessageBox.Show("The selected row does not match the entered name.");
                    }
                }
                else
                {
                    MessageBox.Show("Please select an appointment to pay for.");
                }
            }

            PaymentSignature paymentSignature = new PaymentSignature();
            paymentSignature.ShowDialog();
            
        }

        private void Payment_Load(object sender, EventArgs e)
        {
            DBManager manager = new DBManager();

            try
            {
                DataTable appointments = manager.GetUnpaidAppointments(); // hadyn edit
                dataGridViewAppointments.DataSource = appointments;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was an error: " + ex.Message);
            }
        }

        private void dataGridViewAppointments_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            Services services = new Services();

            if (dataGridViewAppointments.SelectedRows.Count == 1)
            {

                int rowIndex = dataGridViewAppointments.SelectedCells[0].RowIndex;
                DataGridViewRow selectedRow = dataGridViewAppointments.Rows[rowIndex];

                // if statement that checks if the value of the first two cells in the selected row are equal to the name input into the full name textbox
                string rowService = selectedRow.Cells[6].Value.ToString();

                string totalPrice = services.FindPrice(rowService).ToString();

                labelTotalNum.Text = "$" + totalPrice;
            }
            else
            {
                MessageBox.Show("Please select an appointment to cancel.");
            }
        }
    }
}


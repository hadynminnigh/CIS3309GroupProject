﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{
    public partial class PaymentSignature : Form
    {
        public PaymentSignature()
        {
            InitializeComponent();
        }

        float pointX = 0;
        float pointY = 0;

        float lastX = 0;
        float lastY = 0;

        private void panelSignature_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = panelSignature.CreateGraphics();

            g.DrawLine(Pens.Black, pointX, pointY, lastX, lastY);

            lastX = pointX;
            lastY = pointY;
        }

        private void panelSignature_MouseDown(object sender, MouseEventArgs e)
        {
            lastX = e.X;
            lastY = e.Y;
        }

        private void panelSignature_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                pointX = e.X;
                pointY = e.Y;

                panelSignature_Paint(this, null);
            }
        }

        private void buttonConfirm_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            Graphics g = panelSignature.CreateGraphics();
            g.Clear(Color.White);
        }
    }
}

﻿namespace HairSalon
{
    partial class CancellationPayment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonPayment = new System.Windows.Forms.Button();
            this.labelTotalNum = new System.Windows.Forms.Label();
            this.labelTotal = new System.Windows.Forms.Label();
            this.textBoxAddress = new System.Windows.Forms.TextBox();
            this.textBoxCardInfo = new System.Windows.Forms.TextBox();
            this.textBoxFullName = new System.Windows.Forms.TextBox();
            this.labelAddress = new System.Windows.Forms.Label();
            this.labelCardInfo = new System.Windows.Forms.Label();
            this.labelFullName = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonPayment
            // 
            this.buttonPayment.BackColor = System.Drawing.Color.MistyRose;
            this.buttonPayment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPayment.Location = new System.Drawing.Point(290, 316);
            this.buttonPayment.Name = "buttonPayment";
            this.buttonPayment.Size = new System.Drawing.Size(181, 52);
            this.buttonPayment.TabIndex = 25;
            this.buttonPayment.Text = "Confirm Payment";
            this.buttonPayment.UseVisualStyleBackColor = false;
            this.buttonPayment.Click += new System.EventHandler(this.buttonPayment_Click);
            // 
            // labelTotalNum
            // 
            this.labelTotalNum.AutoSize = true;
            this.labelTotalNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalNum.Location = new System.Drawing.Point(297, 87);
            this.labelTotalNum.Name = "labelTotalNum";
            this.labelTotalNum.Size = new System.Drawing.Size(91, 16);
            this.labelTotalNum.TabIndex = 17;
            this.labelTotalNum.Text = "What you owe";
            // 
            // labelTotal
            // 
            this.labelTotal.AutoSize = true;
            this.labelTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotal.Location = new System.Drawing.Point(183, 87);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new System.Drawing.Size(117, 16);
            this.labelTotal.TabIndex = 24;
            this.labelTotal.Text = "Total Amount Due:";
            // 
            // textBoxAddress
            // 
            this.textBoxAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAddress.Location = new System.Drawing.Point(263, 238);
            this.textBoxAddress.Name = "textBoxAddress";
            this.textBoxAddress.Size = new System.Drawing.Size(303, 22);
            this.textBoxAddress.TabIndex = 23;
            // 
            // textBoxCardInfo
            // 
            this.textBoxCardInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxCardInfo.Location = new System.Drawing.Point(263, 189);
            this.textBoxCardInfo.Name = "textBoxCardInfo";
            this.textBoxCardInfo.Size = new System.Drawing.Size(303, 22);
            this.textBoxCardInfo.TabIndex = 22;
            // 
            // textBoxFullName
            // 
            this.textBoxFullName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxFullName.Location = new System.Drawing.Point(263, 140);
            this.textBoxFullName.Name = "textBoxFullName";
            this.textBoxFullName.Size = new System.Drawing.Size(303, 22);
            this.textBoxFullName.TabIndex = 21;
            // 
            // labelAddress
            // 
            this.labelAddress.AutoSize = true;
            this.labelAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAddress.Location = new System.Drawing.Point(184, 241);
            this.labelAddress.Name = "labelAddress";
            this.labelAddress.Size = new System.Drawing.Size(61, 16);
            this.labelAddress.TabIndex = 20;
            this.labelAddress.Text = "Address:";
            // 
            // labelCardInfo
            // 
            this.labelCardInfo.AutoSize = true;
            this.labelCardInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCardInfo.Location = new System.Drawing.Point(184, 192);
            this.labelCardInfo.Name = "labelCardInfo";
            this.labelCardInfo.Size = new System.Drawing.Size(63, 16);
            this.labelCardInfo.TabIndex = 19;
            this.labelCardInfo.Text = "Card Info:";
            // 
            // labelFullName
            // 
            this.labelFullName.AutoSize = true;
            this.labelFullName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFullName.Location = new System.Drawing.Point(184, 143);
            this.labelFullName.Name = "labelFullName";
            this.labelFullName.Size = new System.Drawing.Size(71, 16);
            this.labelFullName.TabIndex = 18;
            this.labelFullName.Text = "Full Name:";
            // 
            // CancellationPayment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonPayment);
            this.Controls.Add(this.labelTotalNum);
            this.Controls.Add(this.labelTotal);
            this.Controls.Add(this.textBoxAddress);
            this.Controls.Add(this.textBoxCardInfo);
            this.Controls.Add(this.textBoxFullName);
            this.Controls.Add(this.labelAddress);
            this.Controls.Add(this.labelCardInfo);
            this.Controls.Add(this.labelFullName);
            this.Name = "CancellationPayment";
            this.Text = "Cancellation Payment";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonPayment;
        private System.Windows.Forms.Label labelTotalNum;
        private System.Windows.Forms.Label labelTotal;
        private System.Windows.Forms.TextBox textBoxAddress;
        private System.Windows.Forms.TextBox textBoxCardInfo;
        private System.Windows.Forms.TextBox textBoxFullName;
        private System.Windows.Forms.Label labelAddress;
        private System.Windows.Forms.Label labelCardInfo;
        private System.Windows.Forms.Label labelFullName;
    }
}
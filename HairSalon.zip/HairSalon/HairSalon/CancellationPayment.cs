﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{
    public partial class CancellationPayment : Form
    {

        DBManager db;
        public CancellationPayment()
        {
            InitializeComponent();
            db = new DBManager();
        }
        
        public string LabelTotalNum
        {
            set { labelTotalNum.Text = value; }
        }
        private string firstName;
        public string FirstName
        {
            get {  return firstName; }
            set { firstName = value; }
        }
        private string lastName;
        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }
        private DateTime aptDate;
        public DateTime AptDate
        {
            get { return aptDate; }
            set { aptDate = value; }
        }


        private void buttonPayment_Click(object sender, EventArgs e)
        {
            string customerName = firstName + " " + lastName;

            if (textBoxCardInfo.Text == "")
            {
                MessageBox.Show("Please input your card details.");
            }
            if (textBoxAddress.Text == "")
            {
                MessageBox.Show("Please input your address.");
            }
            else
            {
                string fullName = textBoxFullName.Text;

                if (fullName == customerName)
                {
                    //db.UpdateAptDate(firstName, lastName);
                    db.CancelAppointment(firstName, lastName);
                }
                else
                {
                    MessageBox.Show("The selected row does not match the entered name.");
                }
            }

            PaymentSignature paymentSignature = new PaymentSignature();
            paymentSignature.ShowDialog();
     
        }
    }
}

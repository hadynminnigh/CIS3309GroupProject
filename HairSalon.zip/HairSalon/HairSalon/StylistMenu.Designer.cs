﻿namespace HairSalon
{
    partial class StylistMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelWelcomeMessage = new System.Windows.Forms.Label();
            this.buttonMakePayment = new System.Windows.Forms.Button();
            this.buttonSearchProducts = new System.Windows.Forms.Button();
            this.buttonModifySchedules = new System.Windows.Forms.Button();
            this.buttonViewAppointments = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelWelcomeMessage
            // 
            this.labelWelcomeMessage.AutoSize = true;
            this.labelWelcomeMessage.Font = new System.Drawing.Font("Palanquin Dark Medium", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelWelcomeMessage.Location = new System.Drawing.Point(312, 140);
            this.labelWelcomeMessage.Name = "labelWelcomeMessage";
            this.labelWelcomeMessage.Size = new System.Drawing.Size(167, 55);
            this.labelWelcomeMessage.TabIndex = 9;
            this.labelWelcomeMessage.Text = "Welcome!";
            // 
            // buttonMakePayment
            // 
            this.buttonMakePayment.BackColor = System.Drawing.Color.MistyRose;
            this.buttonMakePayment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMakePayment.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMakePayment.Location = new System.Drawing.Point(582, 247);
            this.buttonMakePayment.Name = "buttonMakePayment";
            this.buttonMakePayment.Size = new System.Drawing.Size(150, 64);
            this.buttonMakePayment.TabIndex = 8;
            this.buttonMakePayment.Text = "Make Payment";
            this.buttonMakePayment.UseVisualStyleBackColor = false;
            this.buttonMakePayment.Click += new System.EventHandler(this.buttonMakePayment_Click);
            // 
            // buttonSearchProducts
            // 
            this.buttonSearchProducts.BackColor = System.Drawing.Color.MistyRose;
            this.buttonSearchProducts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSearchProducts.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSearchProducts.Location = new System.Drawing.Point(411, 247);
            this.buttonSearchProducts.Name = "buttonSearchProducts";
            this.buttonSearchProducts.Size = new System.Drawing.Size(150, 64);
            this.buttonSearchProducts.TabIndex = 7;
            this.buttonSearchProducts.Text = "Search Products";
            this.buttonSearchProducts.UseVisualStyleBackColor = false;
            this.buttonSearchProducts.Click += new System.EventHandler(this.buttonSearchProducts_Click);
            // 
            // buttonModifySchedules
            // 
            this.buttonModifySchedules.BackColor = System.Drawing.Color.MistyRose;
            this.buttonModifySchedules.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonModifySchedules.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonModifySchedules.Location = new System.Drawing.Point(238, 247);
            this.buttonModifySchedules.Name = "buttonModifySchedules";
            this.buttonModifySchedules.Size = new System.Drawing.Size(150, 64);
            this.buttonModifySchedules.TabIndex = 6;
            this.buttonModifySchedules.Text = "Modify Schedule";
            this.buttonModifySchedules.UseVisualStyleBackColor = false;
            this.buttonModifySchedules.Click += new System.EventHandler(this.buttonModifySchedules_Click);
            // 
            // buttonViewAppointments
            // 
            this.buttonViewAppointments.BackColor = System.Drawing.Color.MistyRose;
            this.buttonViewAppointments.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonViewAppointments.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonViewAppointments.Location = new System.Drawing.Point(68, 247);
            this.buttonViewAppointments.Name = "buttonViewAppointments";
            this.buttonViewAppointments.Size = new System.Drawing.Size(150, 64);
            this.buttonViewAppointments.TabIndex = 5;
            this.buttonViewAppointments.Text = "View Appointments";
            this.buttonViewAppointments.UseVisualStyleBackColor = false;
            this.buttonViewAppointments.Click += new System.EventHandler(this.buttonViewAppointments_Click);
            // 
            // StylistMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labelWelcomeMessage);
            this.Controls.Add(this.buttonMakePayment);
            this.Controls.Add(this.buttonSearchProducts);
            this.Controls.Add(this.buttonModifySchedules);
            this.Controls.Add(this.buttonViewAppointments);
            this.Name = "StylistMenu";
            this.Text = "Stylist Menu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelWelcomeMessage;
        private System.Windows.Forms.Button buttonMakePayment;
        private System.Windows.Forms.Button buttonSearchProducts;
        private System.Windows.Forms.Button buttonModifySchedules;
        private System.Windows.Forms.Button buttonViewAppointments;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{
    public partial class RecMenu : Form
    {
        public RecMenu()
        {
            InitializeComponent();
        }

        private void buttonViewAppointments_Click(object sender, EventArgs e)
        {
            RecAppointments recAppointments = new RecAppointments();
            recAppointments.ShowDialog();
        }

        private void buttonViewSchedules_Click(object sender, EventArgs e)
        {
            RecSchedules recSchedules = new RecSchedules();
            recSchedules.ShowDialog();
        }

        private void buttonSearchProducts_Click(object sender, EventArgs e)
        {
            Products recProducts = new Products();
            recProducts.ShowDialog();
        }

        private void buttonMakePayment_Click(object sender, EventArgs e)
        {
            Payment recPayment = new Payment();
            recPayment.ShowDialog();
        }
    }
}

﻿namespace HairSalon
{
    partial class Payment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelFullName = new System.Windows.Forms.Label();
            this.labelCardInfo = new System.Windows.Forms.Label();
            this.labelAddress = new System.Windows.Forms.Label();
            this.textBoxFullName = new System.Windows.Forms.TextBox();
            this.textBoxCardInfo = new System.Windows.Forms.TextBox();
            this.textBoxAddress = new System.Windows.Forms.TextBox();
            this.labelTotal = new System.Windows.Forms.Label();
            this.labelTotalNum = new System.Windows.Forms.Label();
            this.buttonPayment = new System.Windows.Forms.Button();
            this.labelTableHeader = new System.Windows.Forms.Label();
            this.dataGridViewAppointments = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAppointments)).BeginInit();
            this.SuspendLayout();
            // 
            // labelFullName
            // 
            this.labelFullName.AutoSize = true;
            this.labelFullName.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFullName.Location = new System.Drawing.Point(29, 103);
            this.labelFullName.Name = "labelFullName";
            this.labelFullName.Size = new System.Drawing.Size(73, 26);
            this.labelFullName.TabIndex = 2;
            this.labelFullName.Text = "Full Name:";
            // 
            // labelCardInfo
            // 
            this.labelCardInfo.AutoSize = true;
            this.labelCardInfo.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCardInfo.Location = new System.Drawing.Point(29, 152);
            this.labelCardInfo.Name = "labelCardInfo";
            this.labelCardInfo.Size = new System.Drawing.Size(70, 26);
            this.labelCardInfo.TabIndex = 3;
            this.labelCardInfo.Text = "Card Info:";
            // 
            // labelAddress
            // 
            this.labelAddress.AutoSize = true;
            this.labelAddress.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAddress.Location = new System.Drawing.Point(29, 201);
            this.labelAddress.Name = "labelAddress";
            this.labelAddress.Size = new System.Drawing.Size(62, 26);
            this.labelAddress.TabIndex = 4;
            this.labelAddress.Text = "Address:";
            // 
            // textBoxFullName
            // 
            this.textBoxFullName.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxFullName.Location = new System.Drawing.Point(108, 100);
            this.textBoxFullName.Name = "textBoxFullName";
            this.textBoxFullName.Size = new System.Drawing.Size(303, 31);
            this.textBoxFullName.TabIndex = 5;
            // 
            // textBoxCardInfo
            // 
            this.textBoxCardInfo.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxCardInfo.Location = new System.Drawing.Point(108, 149);
            this.textBoxCardInfo.Name = "textBoxCardInfo";
            this.textBoxCardInfo.Size = new System.Drawing.Size(303, 31);
            this.textBoxCardInfo.TabIndex = 6;
            // 
            // textBoxAddress
            // 
            this.textBoxAddress.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAddress.Location = new System.Drawing.Point(108, 198);
            this.textBoxAddress.Name = "textBoxAddress";
            this.textBoxAddress.Size = new System.Drawing.Size(303, 31);
            this.textBoxAddress.TabIndex = 7;
            // 
            // labelTotal
            // 
            this.labelTotal.AutoSize = true;
            this.labelTotal.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotal.Location = new System.Drawing.Point(28, 47);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new System.Drawing.Size(122, 26);
            this.labelTotal.TabIndex = 8;
            this.labelTotal.Text = "Total Amount Due:";
            // 
            // labelTotalNum
            // 
            this.labelTotalNum.AutoSize = true;
            this.labelTotalNum.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalNum.Location = new System.Drawing.Point(156, 47);
            this.labelTotalNum.Name = "labelTotalNum";
            this.labelTotalNum.Size = new System.Drawing.Size(116, 26);
            this.labelTotalNum.TabIndex = 2;
            this.labelTotalNum.Text = "Total placeholder";
            // 
            // buttonPayment
            // 
            this.buttonPayment.BackColor = System.Drawing.Color.MistyRose;
            this.buttonPayment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPayment.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPayment.Location = new System.Drawing.Point(423, 295);
            this.buttonPayment.Name = "buttonPayment";
            this.buttonPayment.Size = new System.Drawing.Size(181, 52);
            this.buttonPayment.TabIndex = 16;
            this.buttonPayment.Text = "Confirm Payment";
            this.buttonPayment.UseVisualStyleBackColor = false;
            this.buttonPayment.Click += new System.EventHandler(this.buttonPayment_Click);
            // 
            // labelTableHeader
            // 
            this.labelTableHeader.AutoSize = true;
            this.labelTableHeader.Font = new System.Drawing.Font("Palanquin Dark Medium", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTableHeader.Location = new System.Drawing.Point(615, 10);
            this.labelTableHeader.Name = "labelTableHeader";
            this.labelTableHeader.Size = new System.Drawing.Size(227, 55);
            this.labelTableHeader.TabIndex = 19;
            this.labelTableHeader.Text = "Appointments";
            // 
            // dataGridViewAppointments
            // 
            this.dataGridViewAppointments.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewAppointments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAppointments.Location = new System.Drawing.Point(468, 76);
            this.dataGridViewAppointments.Name = "dataGridViewAppointments";
            this.dataGridViewAppointments.Size = new System.Drawing.Size(503, 153);
            this.dataGridViewAppointments.TabIndex = 17;
            this.dataGridViewAppointments.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridViewStylistSchedules_RowHeaderMouseClick);
            // 
            // Payment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1066, 384);
            this.Controls.Add(this.labelTableHeader);
            this.Controls.Add(this.dataGridViewAppointments);
            this.Controls.Add(this.buttonPayment);
            this.Controls.Add(this.labelTotalNum);
            this.Controls.Add(this.labelTotal);
            this.Controls.Add(this.textBoxAddress);
            this.Controls.Add(this.textBoxCardInfo);
            this.Controls.Add(this.textBoxFullName);
            this.Controls.Add(this.labelAddress);
            this.Controls.Add(this.labelCardInfo);
            this.Controls.Add(this.labelFullName);
            this.Name = "Payment";
            this.Text = "Make A Payment";
            this.Load += new System.EventHandler(this.Payment_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAppointments)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labelFullName;
        private System.Windows.Forms.Label labelCardInfo;
        private System.Windows.Forms.Label labelAddress;
        private System.Windows.Forms.TextBox textBoxFullName;
        private System.Windows.Forms.TextBox textBoxCardInfo;
        private System.Windows.Forms.TextBox textBoxAddress;
        private System.Windows.Forms.Label labelTotal;
        private System.Windows.Forms.Label labelTotalNum;
        private System.Windows.Forms.Button buttonPayment;
        private System.Windows.Forms.Label labelTableHeader;
        private System.Windows.Forms.DataGridView dataGridViewAppointments;
    }
}
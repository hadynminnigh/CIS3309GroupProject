﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            string username = textBoxUsername.Text;
            string password = textBoxPassword.Text;

            DBManager manager = new DBManager();

            if (manager.CheckLogin(username, password) == true)
            {
                if (manager.AccountType(username,password) == "Receptionist" /*||manager.AccountType(username, password) == "Administrator"*/)
                {
                    RecMenu recMenu = new RecMenu();
                    recMenu.Show();
                }
                else if (manager.AccountType(username, password) == "Stylist" || manager.AccountType(username, password) == "Administrator")
                {
                    StylistMenu stylistMenu = new StylistMenu();
                    stylistMenu.Show();
                }
                else if (manager.AccountType(username, password) == "Customer" || manager.AccountType(username, password) == "Administrator")
                {
                    // open customer menu
                }
                else
                {
                    MessageBox.Show("An error has occurred");
                }
                MessageBox.Show("Account type (for testing): " + manager.AccountType(username, password));
            }
            else
            {
                MessageBox.Show("Username or Password is incorrect. Please try again!");
            }
        }
    }
}

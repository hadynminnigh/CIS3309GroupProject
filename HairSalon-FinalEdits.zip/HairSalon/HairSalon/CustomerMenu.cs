﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{
    public partial class CustomerMenu : Form
    {
        public CustomerMenu()
        {
            InitializeComponent();
        }

        private void buttonMyAppointments_Click(object sender, EventArgs e)
        {
            CustomerAppointments customerAppointments = new CustomerAppointments();
            customerAppointments.ShowDialog();
        }

        private void buttonMeetTheStylists_Click(object sender, EventArgs e)
        {
            RecSchedules recSchedules = new RecSchedules();
            recSchedules.ShowDialog();
        }

        private void buttonSearchProducts_Click(object sender, EventArgs e)
        {
            Products products = new Products();
            products.ShowDialog();
        }

        private void buttonMakePayment_Click(object sender, EventArgs e)
        {
            Payment payment = new Payment();
            payment.ShowDialog();
        }
    }
}

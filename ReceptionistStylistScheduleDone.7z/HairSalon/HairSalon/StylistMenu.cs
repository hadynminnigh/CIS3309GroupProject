﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{
    public partial class StylistMenu : Form
    {
        public StylistMenu()
        {
            InitializeComponent();
        }

        private void buttonViewAppointments_Click(object sender, EventArgs e)
        {
            StylistAppointments stylistAppointments = new StylistAppointments();
            stylistAppointments.ShowDialog();
        }

        private void buttonModifySchedules_Click(object sender, EventArgs e)
        {
            StylistSchedule stylistSchedule = new StylistSchedule();
            stylistSchedule.ShowDialog();
        }

        private void buttonSearchProducts_Click(object sender, EventArgs e)
        {
            Products products = new Products();
            products.ShowDialog();
        }

        private void buttonMakePayment_Click(object sender, EventArgs e)
        {
            Payment payment = new Payment();
            payment.ShowDialog();
        }
    }
}

﻿namespace HairSalon
{
    partial class RecSchedules
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelTableHeader = new System.Windows.Forms.Label();
            this.dataGridViewStylists = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxStylist = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStylists)).BeginInit();
            this.SuspendLayout();
            // 
            // labelTableHeader
            // 
            this.labelTableHeader.AutoSize = true;
            this.labelTableHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTableHeader.Location = new System.Drawing.Point(340, 42);
            this.labelTableHeader.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelTableHeader.Name = "labelTableHeader";
            this.labelTableHeader.Size = new System.Drawing.Size(284, 42);
            this.labelTableHeader.TabIndex = 10;
            this.labelTableHeader.Text = "Stylists\' Details";
            // 
            // dataGridViewStylists
            // 
            this.dataGridViewStylists.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewStylists.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewStylists.Location = new System.Drawing.Point(83, 129);
            this.dataGridViewStylists.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridViewStylists.Name = "dataGridViewStylists";
            this.dataGridViewStylists.RowHeadersWidth = 51;
            this.dataGridViewStylists.Size = new System.Drawing.Size(903, 262);
            this.dataGridViewStylists.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(213, 443);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(228, 25);
            this.label1.TabIndex = 11;
            this.label1.Text = "Search by stylist\'s name:";
            // 
            // comboBoxStylist
            // 
            this.comboBoxStylist.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxStylist.FormattingEnabled = true;
            this.comboBoxStylist.Items.AddRange(new object[] {
            "Sarah Johnson",
            "Marrissa Brown",
            "Emily Davis",
            "Gwen Wilson",
            "Raven Hawthrone"});
            this.comboBoxStylist.Location = new System.Drawing.Point(469, 443);
            this.comboBoxStylist.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBoxStylist.Name = "comboBoxStylist";
            this.comboBoxStylist.Size = new System.Drawing.Size(396, 28);
            this.comboBoxStylist.TabIndex = 12;
            this.comboBoxStylist.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // RecSchedules
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.comboBoxStylist);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelTableHeader);
            this.Controls.Add(this.dataGridViewStylists);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "RecSchedules";
            this.Text = "Stylists\' Schedules";
            this.Load += new System.EventHandler(this.RecSchedules_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStylists)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelTableHeader;
        private System.Windows.Forms.DataGridView dataGridViewStylists;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxStylist;
    }
}
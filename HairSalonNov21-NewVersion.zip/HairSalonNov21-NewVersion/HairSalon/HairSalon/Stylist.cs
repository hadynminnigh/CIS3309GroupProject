﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesForProject
{
    internal class Stylist
    {

        private string name;
        private string services;
        private string availability;
    ////will get total pay, expected pay, etc from other class and display in database

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string Services
        {
            get { return services; }
            set { services = value; }
        }
        public string Availability
        {
            get { return availability; }
            set { availability = value; }
        }

        public Stylist(string name, string services, string availability)
        {
            this.name = name;
            this.services = services;
            this.availability = availability;
        }
    }
}

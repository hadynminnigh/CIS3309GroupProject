﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairSalon
{
    internal class dbManage
    {
        string connection = "provider=Microsoft.ACE.OLEDB.12.0;" + @"Data Source=HairSalon.accdb;";

        OleDbConnection myConnection;
        DataSet dataSet;
        OleDbDataAdapter dataAdapter;
        OleDbCommandBuilder commandBuilder;

        public dbManage()
        {
            myConnection = new OleDbConnection(connection);
            dataSet = new DataSet();

            dataAdapter = new OleDbDataAdapter("SELECT * FROM Appointments", myConnection);
            commandBuilder = new OleDbCommandBuilder(dataAdapter);
            dataAdapter.Fill(dataSet, "Appointments");

        }

        public List<Appointment> GetAppointments()
        {
            List<Appointment> appointments = new List<Appointment>();

            foreach (DataRow row in dataSet.Tables["Appointments"].Rows)
            {
                Appointment appointment = new Appointment(
                    row["FirstName"].ToString(),
                    row["LastName"].ToString(),
                    row["Email"].ToString(),
                    row["Phonenumber"].ToString(),
                    row["Hairtype"].ToString(),
                    row["Thickness"].ToString(),
                    row["Service"].ToString(),
                    row["Stylist"].ToString()
                );

                appointments.Add(appointment);
            }

            return appointments;
        }
        public void BookAppointment(Appointment appointment)
        {
            DataRow newRow = dataSet.Tables["Appointments"].NewRow();
            newRow["FirstName"] = appointment.FirstName;
            newRow["LastName"] = appointment.LastName;
            newRow["Email"] = appointment.Email;
            newRow["Phonenumber"] = appointment.Phonenumber;
            newRow["Hairtype"] = appointment.Hairtype;
            newRow["HairThickness"] = appointment.Thickness;
            newRow["Service"] = appointment.Service;
            newRow["Stylist"] = appointment.Stylist;

            dataSet.Tables["Appointments"].Rows.Add(newRow);

            dataAdapter.InsertCommand = commandBuilder.GetInsertCommand();
            Update();


        }

        public void Update()
        {
            myConnection.Open();
            dataAdapter.Update(dataSet, "Appointments");
            myConnection.Close();
        }
    }
}
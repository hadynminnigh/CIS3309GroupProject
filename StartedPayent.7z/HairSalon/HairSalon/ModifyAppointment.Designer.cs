﻿namespace HairSalon
{
    partial class ModifyAppointment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelTableHeader = new System.Windows.Forms.Label();
            this.buttonModify = new System.Windows.Forms.Button();
            this.dataGridViewStylistSchedules = new System.Windows.Forms.DataGridView();
            this.groupBoxAppointmentDetails = new System.Windows.Forms.GroupBox();
            this.comboBoxHairType = new System.Windows.Forms.ComboBox();
            this.comboBoxHairThickness = new System.Windows.Forms.ComboBox();
            this.comboBoxService = new System.Windows.Forms.ComboBox();
            this.dateTimePickerAppointmentDate = new System.Windows.Forms.DateTimePicker();
            this.comboBoxStylist = new System.Windows.Forms.ComboBox();
            this.labelAppointmentDate = new System.Windows.Forms.Label();
            this.labelStylist = new System.Windows.Forms.Label();
            this.labelService = new System.Windows.Forms.Label();
            this.labelHairThickness = new System.Windows.Forms.Label();
            this.labelHairType = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStylistSchedules)).BeginInit();
            this.groupBoxAppointmentDetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelTableHeader
            // 
            this.labelTableHeader.AutoSize = true;
            this.labelTableHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTableHeader.Location = new System.Drawing.Point(592, 25);
            this.labelTableHeader.Name = "labelTableHeader";
            this.labelTableHeader.Size = new System.Drawing.Size(254, 33);
            this.labelTableHeader.TabIndex = 12;
            this.labelTableHeader.Text = "Available Stylists";
            // 
            // buttonModify
            // 
            this.buttonModify.BackColor = System.Drawing.Color.MistyRose;
            this.buttonModify.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonModify.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonModify.Location = new System.Drawing.Point(656, 261);
            this.buttonModify.Name = "buttonModify";
            this.buttonModify.Size = new System.Drawing.Size(147, 52);
            this.buttonModify.TabIndex = 11;
            this.buttonModify.Text = "Modify Appointment";
            this.buttonModify.UseVisualStyleBackColor = false;
            this.buttonModify.Click += new System.EventHandler(this.buttonModify_Click_1);
            // 
            // dataGridViewStylistSchedules
            // 
            this.dataGridViewStylistSchedules.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewStylistSchedules.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewStylistSchedules.Location = new System.Drawing.Point(474, 89);
            this.dataGridViewStylistSchedules.Name = "dataGridViewStylistSchedules";
            this.dataGridViewStylistSchedules.Size = new System.Drawing.Size(503, 153);
            this.dataGridViewStylistSchedules.TabIndex = 10;
            this.dataGridViewStylistSchedules.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewStylistSchedules_CellContentClick_1);
            // 
            // groupBoxAppointmentDetails
            // 
            this.groupBoxAppointmentDetails.BackColor = System.Drawing.Color.White;
            this.groupBoxAppointmentDetails.Controls.Add(this.comboBoxHairType);
            this.groupBoxAppointmentDetails.Controls.Add(this.comboBoxHairThickness);
            this.groupBoxAppointmentDetails.Controls.Add(this.comboBoxService);
            this.groupBoxAppointmentDetails.Controls.Add(this.dateTimePickerAppointmentDate);
            this.groupBoxAppointmentDetails.Controls.Add(this.comboBoxStylist);
            this.groupBoxAppointmentDetails.Controls.Add(this.labelAppointmentDate);
            this.groupBoxAppointmentDetails.Controls.Add(this.labelStylist);
            this.groupBoxAppointmentDetails.Controls.Add(this.labelService);
            this.groupBoxAppointmentDetails.Controls.Add(this.labelHairThickness);
            this.groupBoxAppointmentDetails.Controls.Add(this.labelHairType);
            this.groupBoxAppointmentDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxAppointmentDetails.Location = new System.Drawing.Point(22, 25);
            this.groupBoxAppointmentDetails.Name = "groupBoxAppointmentDetails";
            this.groupBoxAppointmentDetails.Size = new System.Drawing.Size(409, 285);
            this.groupBoxAppointmentDetails.TabIndex = 9;
            this.groupBoxAppointmentDetails.TabStop = false;
            this.groupBoxAppointmentDetails.Text = "Customer Information";
            // 
            // comboBoxHairType
            // 
            this.comboBoxHairType.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxHairType.FormattingEnabled = true;
            this.comboBoxHairType.Items.AddRange(new object[] {
            "Straight",
            "Curly",
            "Wavy"});
            this.comboBoxHairType.Location = new System.Drawing.Point(118, 41);
            this.comboBoxHairType.Name = "comboBoxHairType";
            this.comboBoxHairType.Size = new System.Drawing.Size(278, 24);
            this.comboBoxHairType.TabIndex = 32;
            this.comboBoxHairType.SelectedIndexChanged += new System.EventHandler(this.comboBoxHairType_SelectedIndexChanged);
            // 
            // comboBoxHairThickness
            // 
            this.comboBoxHairThickness.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxHairThickness.FormattingEnabled = true;
            this.comboBoxHairThickness.Items.AddRange(new object[] {
            "Thin",
            "Medium",
            "Thick"});
            this.comboBoxHairThickness.Location = new System.Drawing.Point(118, 90);
            this.comboBoxHairThickness.Name = "comboBoxHairThickness";
            this.comboBoxHairThickness.Size = new System.Drawing.Size(278, 24);
            this.comboBoxHairThickness.TabIndex = 31;
            // 
            // comboBoxService
            // 
            this.comboBoxService.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxService.FormattingEnabled = true;
            this.comboBoxService.Items.AddRange(new object[] {
            "Cut",
            "CutAndWash",
            "CurlyCut",
            "BlowOut",
            "Perm",
            "Highlights",
            "Balayage",
            "TouchUp",
            "FullColor",
            "ColorConsultation",
            "Extensions"});
            this.comboBoxService.Location = new System.Drawing.Point(118, 139);
            this.comboBoxService.Name = "comboBoxService";
            this.comboBoxService.Size = new System.Drawing.Size(278, 24);
            this.comboBoxService.TabIndex = 30;
            // 
            // dateTimePickerAppointmentDate
            // 
            this.dateTimePickerAppointmentDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerAppointmentDate.Location = new System.Drawing.Point(118, 236);
            this.dateTimePickerAppointmentDate.MinDate = new System.DateTime(2024, 12, 3, 20, 43, 33, 0);
            this.dateTimePickerAppointmentDate.Name = "dateTimePickerAppointmentDate";
            this.dateTimePickerAppointmentDate.Size = new System.Drawing.Size(277, 22);
            this.dateTimePickerAppointmentDate.TabIndex = 29;
            this.dateTimePickerAppointmentDate.Value = new System.DateTime(2024, 12, 3, 20, 43, 33, 0);
            // 
            // comboBoxStylist
            // 
            this.comboBoxStylist.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxStylist.FormattingEnabled = true;
            this.comboBoxStylist.Items.AddRange(new object[] {
            "Sarah Johnson",
            "Marrissa Brown",
            "Emily Davis",
            "Gwen Wilson",
            "Raven Hawthrone"});
            this.comboBoxStylist.Location = new System.Drawing.Point(118, 189);
            this.comboBoxStylist.Name = "comboBoxStylist";
            this.comboBoxStylist.Size = new System.Drawing.Size(278, 24);
            this.comboBoxStylist.TabIndex = 28;
            // 
            // labelAppointmentDate
            // 
            this.labelAppointmentDate.AutoSize = true;
            this.labelAppointmentDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAppointmentDate.Location = new System.Drawing.Point(12, 240);
            this.labelAppointmentDate.Name = "labelAppointmentDate";
            this.labelAppointmentDate.Size = new System.Drawing.Size(39, 16);
            this.labelAppointmentDate.TabIndex = 25;
            this.labelAppointmentDate.Text = "Date:";
            // 
            // labelStylist
            // 
            this.labelStylist.AutoSize = true;
            this.labelStylist.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStylist.Location = new System.Drawing.Point(12, 191);
            this.labelStylist.Name = "labelStylist";
            this.labelStylist.Size = new System.Drawing.Size(45, 16);
            this.labelStylist.TabIndex = 21;
            this.labelStylist.Text = "Stylist:";
            // 
            // labelService
            // 
            this.labelService.AutoSize = true;
            this.labelService.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelService.Location = new System.Drawing.Point(12, 142);
            this.labelService.Name = "labelService";
            this.labelService.Size = new System.Drawing.Size(56, 16);
            this.labelService.TabIndex = 20;
            this.labelService.Text = "Service:";
            // 
            // labelHairThickness
            // 
            this.labelHairThickness.AutoSize = true;
            this.labelHairThickness.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHairThickness.Location = new System.Drawing.Point(12, 93);
            this.labelHairThickness.Name = "labelHairThickness";
            this.labelHairThickness.Size = new System.Drawing.Size(100, 16);
            this.labelHairThickness.TabIndex = 16;
            this.labelHairThickness.Text = "Hair Thickness:";
            // 
            // labelHairType
            // 
            this.labelHairType.AutoSize = true;
            this.labelHairType.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHairType.Location = new System.Drawing.Point(12, 44);
            this.labelHairType.Name = "labelHairType";
            this.labelHairType.Size = new System.Drawing.Size(70, 16);
            this.labelHairType.TabIndex = 15;
            this.labelHairType.Text = "Hair Type:";
            // 
            // ModifyAppointment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1003, 343);
            this.Controls.Add(this.labelTableHeader);
            this.Controls.Add(this.buttonModify);
            this.Controls.Add(this.dataGridViewStylistSchedules);
            this.Controls.Add(this.groupBoxAppointmentDetails);
            this.Name = "ModifyAppointment";
            this.Text = "Modify Your Appointment";
            this.Load += new System.EventHandler(this.ModifyAppointment_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStylistSchedules)).EndInit();
            this.groupBoxAppointmentDetails.ResumeLayout(false);
            this.groupBoxAppointmentDetails.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelTableHeader;
        private System.Windows.Forms.Button buttonModify;
        private System.Windows.Forms.DataGridView dataGridViewStylistSchedules;
        private System.Windows.Forms.GroupBox groupBoxAppointmentDetails;
        private System.Windows.Forms.ComboBox comboBoxHairType;
        private System.Windows.Forms.ComboBox comboBoxHairThickness;
        private System.Windows.Forms.ComboBox comboBoxService;
        private System.Windows.Forms.DateTimePicker dateTimePickerAppointmentDate;
        private System.Windows.Forms.ComboBox comboBoxStylist;
        private System.Windows.Forms.Label labelAppointmentDate;
        private System.Windows.Forms.Label labelStylist;
        private System.Windows.Forms.Label labelService;
        private System.Windows.Forms.Label labelHairThickness;
        private System.Windows.Forms.Label labelHairType;
    }
}
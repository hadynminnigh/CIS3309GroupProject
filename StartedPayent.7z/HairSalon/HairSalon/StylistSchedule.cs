﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{
    public partial class StylistSchedule : Form
    {
        public StylistSchedule()
        {
            InitializeComponent();
        }

        private void StylistSchedule_Load(object sender, EventArgs e)
        {
            DBManager manager = new DBManager();

            try
            {
                DataTable schedule = manager.GetSchedule(); // this will be a method that only displays stylist name and availability
                dataGridViewSchedule.DataSource = schedule;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was an error: " + ex.Message);
            }
        }
    }
}

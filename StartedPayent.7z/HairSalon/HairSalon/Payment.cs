﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{
    public partial class Payment : Form
    {
        public Payment()
        {
            InitializeComponent();
        }

        private void buttonPayment_Click(object sender, EventArgs e) // hadyn edit... this was a copy paste there might be issues
        {
            if (dataGridViewAppointments.SelectedRows.Count > 0)
            {

                int rowIndex = dataGridViewAppointments.SelectedCells[0].RowIndex;
                DataGridViewRow selectedRow = dataGridViewAppointments.Rows[rowIndex];

                // if customer name inputed = to one in datagridview

                db.CancelAppointment(firstName, lastName, aptDate);

                LoadAppointments();
            }
            else
            {
                MessageBox.Show("Please select an appointment to cancel.");
            }
        }

        private void dataGridViewStylistSchedules_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            // wheb a row is selected, that is the one that may be changed
            // also only display appointments that havent been paid for
        }

        private void Payment_Load(object sender, EventArgs e)
        {
            DBManager manager = new DBManager();

            try
            {
                DataTable appointments = manager.GetUnpaidAppointments(); // hadyn edit
                dataGridViewAppointments.DataSource = appointments;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was an error: " + ex.Message);
            }
        }
    }
}


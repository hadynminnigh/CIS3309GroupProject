﻿namespace HairSalon
{
    partial class BookAppointment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxAppointmentDetails = new System.Windows.Forms.GroupBox();
            this.comboBoxHairType = new System.Windows.Forms.ComboBox();
            this.comboBoxHairThickness = new System.Windows.Forms.ComboBox();
            this.comboBoxService = new System.Windows.Forms.ComboBox();
            this.dateTimePickerAppointmentDate = new System.Windows.Forms.DateTimePicker();
            this.comboBoxStylist = new System.Windows.Forms.ComboBox();
            this.labelAppointmentDate = new System.Windows.Forms.Label();
            this.labelStylist = new System.Windows.Forms.Label();
            this.labelService = new System.Windows.Forms.Label();
            this.textBoxPhoneNumber = new System.Windows.Forms.TextBox();
            this.labelHairThickness = new System.Windows.Forms.Label();
            this.labelHairType = new System.Windows.Forms.Label();
            this.labelPhoneNumber = new System.Windows.Forms.Label();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.textBoxLastName = new System.Windows.Forms.TextBox();
            this.textBoxFirstName = new System.Windows.Forms.TextBox();
            this.labelEmail = new System.Windows.Forms.Label();
            this.labelLastName = new System.Windows.Forms.Label();
            this.labelFirstName = new System.Windows.Forms.Label();
            this.labelTableHeader = new System.Windows.Forms.Label();
            this.buttonBook = new System.Windows.Forms.Button();
            this.dataGridViewStylistSchedules = new System.Windows.Forms.DataGridView();
            this.groupBoxAppointmentDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStylistSchedules)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxAppointmentDetails
            // 
            this.groupBoxAppointmentDetails.BackColor = System.Drawing.Color.White;
            this.groupBoxAppointmentDetails.Controls.Add(this.comboBoxHairType);
            this.groupBoxAppointmentDetails.Controls.Add(this.comboBoxHairThickness);
            this.groupBoxAppointmentDetails.Controls.Add(this.comboBoxService);
            this.groupBoxAppointmentDetails.Controls.Add(this.dateTimePickerAppointmentDate);
            this.groupBoxAppointmentDetails.Controls.Add(this.comboBoxStylist);
            this.groupBoxAppointmentDetails.Controls.Add(this.labelAppointmentDate);
            this.groupBoxAppointmentDetails.Controls.Add(this.labelStylist);
            this.groupBoxAppointmentDetails.Controls.Add(this.labelService);
            this.groupBoxAppointmentDetails.Controls.Add(this.textBoxPhoneNumber);
            this.groupBoxAppointmentDetails.Controls.Add(this.labelHairThickness);
            this.groupBoxAppointmentDetails.Controls.Add(this.labelHairType);
            this.groupBoxAppointmentDetails.Controls.Add(this.labelPhoneNumber);
            this.groupBoxAppointmentDetails.Controls.Add(this.textBoxEmail);
            this.groupBoxAppointmentDetails.Controls.Add(this.textBoxLastName);
            this.groupBoxAppointmentDetails.Controls.Add(this.textBoxFirstName);
            this.groupBoxAppointmentDetails.Controls.Add(this.labelEmail);
            this.groupBoxAppointmentDetails.Controls.Add(this.labelLastName);
            this.groupBoxAppointmentDetails.Controls.Add(this.labelFirstName);
            this.groupBoxAppointmentDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxAppointmentDetails.Location = new System.Drawing.Point(29, 26);
            this.groupBoxAppointmentDetails.Name = "groupBoxAppointmentDetails";
            this.groupBoxAppointmentDetails.Size = new System.Drawing.Size(409, 482);
            this.groupBoxAppointmentDetails.TabIndex = 1;
            this.groupBoxAppointmentDetails.TabStop = false;
            this.groupBoxAppointmentDetails.Text = "Customer Information";
            // 
            // comboBoxHairType
            // 
            this.comboBoxHairType.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxHairType.FormattingEnabled = true;
            this.comboBoxHairType.Items.AddRange(new object[] {
            "Straight",
            "Curly",
            "Wavy"});
            this.comboBoxHairType.Location = new System.Drawing.Point(118, 236);
            this.comboBoxHairType.Name = "comboBoxHairType";
            this.comboBoxHairType.Size = new System.Drawing.Size(278, 24);
            this.comboBoxHairType.TabIndex = 32;
            // 
            // comboBoxHairThickness
            // 
            this.comboBoxHairThickness.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxHairThickness.FormattingEnabled = true;
            this.comboBoxHairThickness.Items.AddRange(new object[] {
            "Thin",
            "Medium",
            "Thick"});
            this.comboBoxHairThickness.Location = new System.Drawing.Point(118, 285);
            this.comboBoxHairThickness.Name = "comboBoxHairThickness";
            this.comboBoxHairThickness.Size = new System.Drawing.Size(278, 24);
            this.comboBoxHairThickness.TabIndex = 31;
            // 
            // comboBoxService
            // 
            this.comboBoxService.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxService.FormattingEnabled = true;
            this.comboBoxService.Items.AddRange(new object[] {
            "Cut",
            "CutAndWash",
            "CurlyCut",
            "BlowOut",
            "Perm",
            "Highlights",
            "Balayage",
            "TouchUp",
            "FullColor",
            "ColorConsultation",
            "Extensions"});
            this.comboBoxService.Location = new System.Drawing.Point(118, 334);
            this.comboBoxService.Name = "comboBoxService";
            this.comboBoxService.Size = new System.Drawing.Size(278, 24);
            this.comboBoxService.TabIndex = 30;
            this.comboBoxService.SelectedIndexChanged += new System.EventHandler(this.comboBoxService_SelectedIndexChanged_1);
            // 
            // dateTimePickerAppointmentDate
            // 
            this.dateTimePickerAppointmentDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerAppointmentDate.Location = new System.Drawing.Point(118, 431);
            this.dateTimePickerAppointmentDate.Name = "dateTimePickerAppointmentDate";
            this.dateTimePickerAppointmentDate.Size = new System.Drawing.Size(277, 22);
            this.dateTimePickerAppointmentDate.TabIndex = 29;
            this.dateTimePickerAppointmentDate.ValueChanged += new System.EventHandler(this.dateTimePickerAppointmentDate_ValueChanged);
            // 
            // comboBoxStylist
            // 
            this.comboBoxStylist.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxStylist.FormattingEnabled = true;
            this.comboBoxStylist.Items.AddRange(new object[] {
            "Sarah Johnson",
            "Marrissa Brown",
            "Emily Davis",
            "Gwen Wilson",
            "Raven Hawthrone"});
            this.comboBoxStylist.Location = new System.Drawing.Point(118, 384);
            this.comboBoxStylist.Name = "comboBoxStylist";
            this.comboBoxStylist.Size = new System.Drawing.Size(278, 24);
            this.comboBoxStylist.TabIndex = 28;
            // 
            // labelAppointmentDate
            // 
            this.labelAppointmentDate.AutoSize = true;
            this.labelAppointmentDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAppointmentDate.Location = new System.Drawing.Point(12, 435);
            this.labelAppointmentDate.Name = "labelAppointmentDate";
            this.labelAppointmentDate.Size = new System.Drawing.Size(39, 16);
            this.labelAppointmentDate.TabIndex = 25;
            this.labelAppointmentDate.Text = "Date:";
            // 
            // labelStylist
            // 
            this.labelStylist.AutoSize = true;
            this.labelStylist.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStylist.Location = new System.Drawing.Point(12, 386);
            this.labelStylist.Name = "labelStylist";
            this.labelStylist.Size = new System.Drawing.Size(45, 16);
            this.labelStylist.TabIndex = 21;
            this.labelStylist.Text = "Stylist:";
            // 
            // labelService
            // 
            this.labelService.AutoSize = true;
            this.labelService.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelService.Location = new System.Drawing.Point(12, 337);
            this.labelService.Name = "labelService";
            this.labelService.Size = new System.Drawing.Size(56, 16);
            this.labelService.TabIndex = 20;
            this.labelService.Text = "Service:";
            // 
            // textBoxPhoneNumber
            // 
            this.textBoxPhoneNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPhoneNumber.Location = new System.Drawing.Point(93, 187);
            this.textBoxPhoneNumber.Name = "textBoxPhoneNumber";
            this.textBoxPhoneNumber.Size = new System.Drawing.Size(303, 22);
            this.textBoxPhoneNumber.TabIndex = 17;
            // 
            // labelHairThickness
            // 
            this.labelHairThickness.AutoSize = true;
            this.labelHairThickness.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHairThickness.Location = new System.Drawing.Point(12, 288);
            this.labelHairThickness.Name = "labelHairThickness";
            this.labelHairThickness.Size = new System.Drawing.Size(100, 16);
            this.labelHairThickness.TabIndex = 16;
            this.labelHairThickness.Text = "Hair Thickness:";
            // 
            // labelHairType
            // 
            this.labelHairType.AutoSize = true;
            this.labelHairType.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHairType.Location = new System.Drawing.Point(12, 239);
            this.labelHairType.Name = "labelHairType";
            this.labelHairType.Size = new System.Drawing.Size(70, 16);
            this.labelHairType.TabIndex = 15;
            this.labelHairType.Text = "Hair Type:";
            // 
            // labelPhoneNumber
            // 
            this.labelPhoneNumber.AutoSize = true;
            this.labelPhoneNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPhoneNumber.Location = new System.Drawing.Point(12, 190);
            this.labelPhoneNumber.Name = "labelPhoneNumber";
            this.labelPhoneNumber.Size = new System.Drawing.Size(49, 16);
            this.labelPhoneNumber.TabIndex = 14;
            this.labelPhoneNumber.Text = "Phone:";
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEmail.Location = new System.Drawing.Point(92, 136);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(303, 22);
            this.textBoxEmail.TabIndex = 13;
            // 
            // textBoxLastName
            // 
            this.textBoxLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLastName.Location = new System.Drawing.Point(92, 87);
            this.textBoxLastName.Name = "textBoxLastName";
            this.textBoxLastName.Size = new System.Drawing.Size(303, 22);
            this.textBoxLastName.TabIndex = 12;
            // 
            // textBoxFirstName
            // 
            this.textBoxFirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxFirstName.Location = new System.Drawing.Point(92, 38);
            this.textBoxFirstName.Name = "textBoxFirstName";
            this.textBoxFirstName.Size = new System.Drawing.Size(303, 22);
            this.textBoxFirstName.TabIndex = 11;
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEmail.Location = new System.Drawing.Point(11, 139);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(44, 16);
            this.labelEmail.TabIndex = 10;
            this.labelEmail.Text = "Email:";
            // 
            // labelLastName
            // 
            this.labelLastName.AutoSize = true;
            this.labelLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLastName.Location = new System.Drawing.Point(11, 90);
            this.labelLastName.Name = "labelLastName";
            this.labelLastName.Size = new System.Drawing.Size(75, 16);
            this.labelLastName.TabIndex = 9;
            this.labelLastName.Text = "Last Name:";
            // 
            // labelFirstName
            // 
            this.labelFirstName.AutoSize = true;
            this.labelFirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFirstName.Location = new System.Drawing.Point(11, 41);
            this.labelFirstName.Name = "labelFirstName";
            this.labelFirstName.Size = new System.Drawing.Size(75, 16);
            this.labelFirstName.TabIndex = 8;
            this.labelFirstName.Text = "First Name:";
            // 
            // labelTableHeader
            // 
            this.labelTableHeader.AutoSize = true;
            this.labelTableHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTableHeader.Location = new System.Drawing.Point(599, 26);
            this.labelTableHeader.Name = "labelTableHeader";
            this.labelTableHeader.Size = new System.Drawing.Size(254, 33);
            this.labelTableHeader.TabIndex = 8;
            this.labelTableHeader.Text = "Available Stylists";
            // 
            // buttonBook
            // 
            this.buttonBook.BackColor = System.Drawing.Color.MistyRose;
            this.buttonBook.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBook.Location = new System.Drawing.Point(666, 409);
            this.buttonBook.Name = "buttonBook";
            this.buttonBook.Size = new System.Drawing.Size(144, 52);
            this.buttonBook.TabIndex = 7;
            this.buttonBook.Text = "Book Appointment";
            this.buttonBook.UseVisualStyleBackColor = false;
            this.buttonBook.Click += new System.EventHandler(this.buttonBook_Click_1);
            // 
            // dataGridViewStylistSchedules
            // 
            this.dataGridViewStylistSchedules.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewStylistSchedules.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewStylistSchedules.Location = new System.Drawing.Point(481, 141);
            this.dataGridViewStylistSchedules.Name = "dataGridViewStylistSchedules";
            this.dataGridViewStylistSchedules.Size = new System.Drawing.Size(503, 213);
            this.dataGridViewStylistSchedules.TabIndex = 6;
            // 
            // BookAppointment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1018, 520);
            this.Controls.Add(this.labelTableHeader);
            this.Controls.Add(this.buttonBook);
            this.Controls.Add(this.dataGridViewStylistSchedules);
            this.Controls.Add(this.groupBoxAppointmentDetails);
            this.Name = "BookAppointment";
            this.Text = "Book Your Appointment";
            this.Load += new System.EventHandler(this.BookAppointment_Load);
            this.groupBoxAppointmentDetails.ResumeLayout(false);
            this.groupBoxAppointmentDetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStylistSchedules)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxAppointmentDetails;
        private System.Windows.Forms.Label labelTableHeader;
        private System.Windows.Forms.Button buttonBook;
        private System.Windows.Forms.DataGridView dataGridViewStylistSchedules;
        private System.Windows.Forms.Label labelStylist;
        private System.Windows.Forms.Label labelService;
        private System.Windows.Forms.TextBox textBoxPhoneNumber;
        private System.Windows.Forms.Label labelHairThickness;
        private System.Windows.Forms.Label labelHairType;
        private System.Windows.Forms.Label labelPhoneNumber;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.TextBox textBoxLastName;
        private System.Windows.Forms.TextBox textBoxFirstName;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.Label labelLastName;
        private System.Windows.Forms.Label labelFirstName;
        private System.Windows.Forms.Label labelAppointmentDate;
        private System.Windows.Forms.ComboBox comboBoxStylist;
        private System.Windows.Forms.ComboBox comboBoxHairThickness;
        private System.Windows.Forms.ComboBox comboBoxService;
        private System.Windows.Forms.DateTimePicker dateTimePickerAppointmentDate;
        private System.Windows.Forms.ComboBox comboBoxHairType;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{
    public partial class Payment : Form
    {
        public Payment()
        {
            InitializeComponent();
        }

        private void buttonPayment_Click(object sender, EventArgs e)
        {
            // will mark an appointment as paid
        }

        private void dataGridViewStylistSchedules_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            // wheb a row is selected, that is the one that may be changed
            // also only display appointments that havent been paid for
        }

        private void Payment_Load(object sender, EventArgs e)
        {
            DBManager manager = new DBManager();

            try
            {
                DataTable appointments = manager.GetAppointments(); // CHANGE THIS TO FILTER TO ONES TAHAT ARE ONLY UNPAID
                dataGridViewAppointments.DataSource = appointments;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was an error: " + ex.Message);
            }
        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{
    public partial class BookAppointment : Form
    {
        public BookAppointment()
        {
            InitializeComponent();
        }

        // we still need all of the values set for the combo boxes

        private void dateTimePickerAppointmentDate_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void BookAppointment_Load(object sender, EventArgs e)
        {
            DBManager manager = new DBManager();

            try
            {
                DataTable stylists = manager.GetStylists();
                dataGridViewStylistSchedules.DataSource = stylists;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was an error: " + ex.Message);
            }
        }
    }
}

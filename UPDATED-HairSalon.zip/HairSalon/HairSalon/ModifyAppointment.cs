﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{

    // also need all combo box choices for these
    // the same as book appointment
    public partial class ModifyAppointment : Form
    {
        public ModifyAppointment()
        {
            InitializeComponent();
        }

        

        private void comboBoxHairType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

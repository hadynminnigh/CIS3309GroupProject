﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace HairSalon
{
    internal class DBManager
    {

        public bool CheckLogin(string username, string password)
        {
            bool loginCorrect = false;

            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" +
                                      "Data Source=HairSalonDB.accdb;";

            string selectSql = "SELECT * FROM logins " + 
                               "WHERE Username = '" + username + "' " +
                               "AND Password = '" + password + "'";

            OleDbConnection myConnection = new OleDbConnection(connectionString);
            OleDbCommand myCommand = new OleDbCommand(selectSql, myConnection);
            OleDbDataReader myDataReader;
            List<string> logins = new List<string>();

            try
            {
                myConnection.Open();
                myDataReader = myCommand.ExecuteReader();

                while(myDataReader.Read())
                {
                    string user = myDataReader["Username"].ToString();
                    logins.Add(user);
                }    
            }
            catch (OleDbException ex)
            { 
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                myConnection.Close();
            }

            if (logins.Count == 0)
            {
                Console.WriteLine("Nothing was found " + logins);
            }
            else
            {
                loginCorrect = true;
            }

            return loginCorrect;
        }

        public string AccountType(string username, string password)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" +
                                      "Data Source=HairSalonDB.accdb;";

            string selectSql = "SELECT AccountType FROM logins " +
                               "WHERE Username = '" + username + "' " +
                               "AND Password = '" + password + "'";

            OleDbConnection myConnection = new OleDbConnection(connectionString);
            OleDbCommand myCommand = new OleDbCommand(selectSql, myConnection);
            OleDbDataReader myDataReader;
            List<string> accountType = new List<string>();

            try
            {
                myConnection.Open();
                myDataReader = myCommand.ExecuteReader();

                while (myDataReader.Read())
                {
                    string type = myDataReader["AccountType"].ToString();
                    accountType.Add(type);
                }
            }
            catch (OleDbException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                myConnection.Close();
            }

            if (accountType.Count == 0)
            {
                Console.WriteLine("Nothing was found " + accountType);
                return "Nothing was found";
            }
            else
            {
                return accountType[0];
            }

            
        }

        public DataTable GetAppointments()
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" +
                                      "Data Source=HairSalonDB.accdb;";

            string selectSql = "SELECT * FROM Appointments";

            OleDbConnection myConnection = new OleDbConnection(connectionString);
            //OleDbCommand myCommand = new OleDbCommand(selectSql, myConnection);
            OleDbDataAdapter myDataAdapter = new OleDbDataAdapter(selectSql, myConnection);
            DataTable appointmentTable = new DataTable();

            try
            {
                myConnection.Open();

                myDataAdapter.Fill(appointmentTable);
            }
            catch (OleDbException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                myConnection.Close();
            }

            return appointmentTable;
        }
    }

    
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{
    public partial class StylistSchedule : Form
    {
        DBManager db;
        public StylistSchedule()
        {
            InitializeComponent();
            db = new DBManager();

        }
        private void StylistSchedule_Load(object sender, EventArgs e)
        {
           
            try
            {
                DataTable schedule = db.GetSchedule();
                dataGridViewSchedule.DataSource = schedule;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was an error: " + ex.Message);
            }
        }

        private void buttonChangeAvailability_Click(object sender, EventArgs e)
        {
            if (dataGridViewSchedule.SelectedRows.Count > 0)
            {
                int selectedRowIndex = dataGridViewSchedule.SelectedCells[0].RowIndex;
                DataGridViewRow selectedRow = dataGridViewSchedule.Rows[selectedRowIndex];

                string stylistName = selectedRow.Cells["StylistName"].Value.ToString();

                db.ChangeAvailability(stylistName);

                DataTable schedule = db.GetSchedule();
                dataGridViewSchedule.DataSource = schedule; 
            }
            else
            {
                MessageBox.Show("Please select a stylist to change availability.");
            }

        }
    }
}

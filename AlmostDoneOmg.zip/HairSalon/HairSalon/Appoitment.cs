﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairSalon
{
    public class Appointment
    {
        private string firstName;
        private string lastName;
        private string email;
        private string phonenumber;
        private string hairtype;
        private string thickness;
        private string service;
        private string stylist;
        private DateTime aptDate;

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        public string Phonenumber
        {
            get { return phonenumber; }
            set { phonenumber = value; }
        }

        public string Hairtype
        {
            get { return hairtype; }
            set { hairtype = value; }
        }

        public string Thickness
        {
            get { return thickness; }
            set { thickness = value; }
        }

        public string Service
        {
            get { return service; }
            set { service = value; }
        }

        public string Stylist
        {
            get { return stylist; }
            set { stylist = value; }
        }
        public DateTime AptDate
        {
            get { return aptDate; }
            set { aptDate = value; }
        }



        public Appointment(string firstName, string lastName, string email, string phonenumber, string hairtype, string thickness, string service, string stylist, DateTime aptDate)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.email = email;
            this.phonenumber = phonenumber;
            this.hairtype = hairtype;
            this.thickness = thickness;
            this.service = service;
            this.stylist = stylist;
            this.aptDate = aptDate;
        }

        public override string ToString()
        {
            return $"{FirstName},{LastName},{Email},{Phonenumber},{Hairtype},{Thickness},{Service},{Stylist},{AptDate:MM/dd/yyyy/hh:mm}";
        }

        public static class BookAppointments
        {
            public static List<Appointment> AppointmentsBooked = new List<Appointment>();
        }
    }
}

﻿namespace HairSalon
{
    partial class PaymentSignature
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelSignature = new System.Windows.Forms.Panel();
            this.labelSign = new System.Windows.Forms.Label();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonConfirm = new System.Windows.Forms.Button();
            this.panelSignature.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelSignature
            // 
            this.panelSignature.Controls.Add(this.labelSign);
            this.panelSignature.Location = new System.Drawing.Point(49, 78);
            this.panelSignature.Name = "panelSignature";
            this.panelSignature.Size = new System.Drawing.Size(689, 279);
            this.panelSignature.TabIndex = 0;
            this.panelSignature.Paint += new System.Windows.Forms.PaintEventHandler(this.panelSignature_Paint);
            this.panelSignature.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelSignature_MouseDown);
            this.panelSignature.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panelSignature_MouseMove);
            // 
            // labelSign
            // 
            this.labelSign.AutoSize = true;
            this.labelSign.Font = new System.Drawing.Font("Palanquin Dark Medium", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSign.Location = new System.Drawing.Point(3, 136);
            this.labelSign.Name = "labelSign";
            this.labelSign.Size = new System.Drawing.Size(210, 68);
            this.labelSign.TabIndex = 9;
            this.labelSign.Text = "Sign Here:";
            // 
            // buttonClear
            // 
            this.buttonClear.BackColor = System.Drawing.Color.LavenderBlush;
            this.buttonClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonClear.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClear.Location = new System.Drawing.Point(64, 386);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(150, 64);
            this.buttonClear.TabIndex = 8;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = false;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonConfirm
            // 
            this.buttonConfirm.BackColor = System.Drawing.Color.MistyRose;
            this.buttonConfirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonConfirm.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonConfirm.Location = new System.Drawing.Point(259, 386);
            this.buttonConfirm.Name = "buttonConfirm";
            this.buttonConfirm.Size = new System.Drawing.Size(150, 64);
            this.buttonConfirm.TabIndex = 7;
            this.buttonConfirm.Text = "Confirm";
            this.buttonConfirm.UseVisualStyleBackColor = false;
            this.buttonConfirm.Click += new System.EventHandler(this.buttonConfirm_Click);
            // 
            // PaymentSignature
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 488);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonConfirm);
            this.Controls.Add(this.panelSignature);
            this.Name = "PaymentSignature";
            this.Text = "PaymentSignature";
            this.panelSignature.ResumeLayout(false);
            this.panelSignature.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelSignature;
        private System.Windows.Forms.Label labelSign;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonConfirm;
    }
}
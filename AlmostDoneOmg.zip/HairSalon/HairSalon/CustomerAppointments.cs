﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{
    public partial class CustomerAppointments : Form
    {
        DBManager db;
        public CustomerAppointments()
        {
            InitializeComponent();
            db = new DBManager();

        }

        private void buttonBook_Click(object sender, EventArgs e)
        {
            BookAppointment bookAppointment = new BookAppointment();
            bookAppointment.ShowDialog();
        }

        private void buttonModify_Click(object sender, EventArgs e)
        {
            ModifyAppointment modifyAppointment = new ModifyAppointment();
            modifyAppointment.ShowDialog();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            int rowIndex = dataGridViewAppointments.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = dataGridViewAppointments.Rows[rowIndex];

            DateTime aptDate = DateTime.Parse(selectedRow.Cells["AptDate"].Value.ToString());
            DateTime now = DateTime.Now;
            DateTime cancellationFeeTime = aptDate.AddDays(-1);

            Services services = new Services();

            string rowService = selectedRow.Cells[6].Value.ToString();
            double totalPrice = services.FindPrice(rowService);
            double cancellationFee = totalPrice / 2;

            string firstName = selectedRow.Cells["FirstName"].Value.ToString();
            string lastName = selectedRow.Cells["LastName"].Value.ToString();

            if (dataGridViewAppointments.SelectedRows.Count > 0)
            {
                if (now > cancellationFeeTime)
                {
                    CancellationPayment cancellationPayment = new CancellationPayment();
                    cancellationPayment.LabelTotalNum = "$" + (cancellationFee.ToString());
                    cancellationPayment.FirstName = firstName;
                    cancellationPayment.LastName = lastName;
                    cancellationPayment.AptDate = aptDate;
                    db.UpdateAptDate(firstName, lastName);
                    db.CancelAppointment(firstName, lastName);
                    cancellationPayment.ShowDialog();
                    //db.CancelAppointment(selectedRow.Cells["FirstName"].Value.ToString(), selectedRow.Cells["LastName"].Value.ToString(), aptDate);
                    LoadAppointments();
                }
                else
                {
                    db.CancelAppointment(firstName, lastName);

                    LoadAppointments();
                }
            }
            else
            {
                MessageBox.Show("Please select an appointment to cancel.");
            }
        }

        private void LoadAppointments()
        {
            DataTable appointments = db.GetAppointments();
            dataGridViewAppointments.DataSource = appointments;
        }

        private void CustomerAppointments_Load(object sender, EventArgs e)
        {
            //DBManager manager = new DBManager();

            //try
            //{
            //    DataTable appointments = manager.GetAppointments();
            //    dataGridViewAppointments.DataSource = appointments;
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show("There was an error: " + ex.Message);
            //}
        }

        private void textBoxFirst_TextChanged(object sender, EventArgs e)
        {
            // 
        }

        private void buttonViewMyAppointments_Click(object sender, EventArgs e)
        {
            string customerFirstName = textBoxFirst.Text.ToString();
            string customerLastName = textBoxLast.Text.ToString();

            List<Appointment> appointments = db.GetAppointmentByCustomer(customerFirstName, customerLastName);

            dataGridViewAppointments.DataSource = appointments;

            
        }
    }
}

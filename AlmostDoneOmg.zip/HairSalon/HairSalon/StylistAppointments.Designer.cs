﻿namespace HairSalon
{
    partial class StylistAppointments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelTableHeader = new System.Windows.Forms.Label();
            this.buttonModify = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonBook = new System.Windows.Forms.Button();
            this.dataGridViewAppointments = new System.Windows.Forms.DataGridView();
            this.buttonCompleteAppointment = new System.Windows.Forms.Button();
            this.buttonViewMyAppointments = new System.Windows.Forms.Button();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.labelName = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAppointments)).BeginInit();
            this.SuspendLayout();
            // 
            // labelTableHeader
            // 
            this.labelTableHeader.AutoSize = true;
            this.labelTableHeader.Font = new System.Drawing.Font("Palanquin Dark Medium", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTableHeader.Location = new System.Drawing.Point(143, 39);
            this.labelTableHeader.Name = "labelTableHeader";
            this.labelTableHeader.Size = new System.Drawing.Size(484, 55);
            this.labelTableHeader.TabIndex = 11;
            this.labelTableHeader.Text = "Appointments Currently Booked";
            // 
            // buttonModify
            // 
            this.buttonModify.BackColor = System.Drawing.Color.MistyRose;
            this.buttonModify.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonModify.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonModify.Location = new System.Drawing.Point(412, 359);
            this.buttonModify.Name = "buttonModify";
            this.buttonModify.Size = new System.Drawing.Size(149, 52);
            this.buttonModify.TabIndex = 10;
            this.buttonModify.Text = "Modify Appointment";
            this.buttonModify.UseVisualStyleBackColor = false;
            this.buttonModify.Click += new System.EventHandler(this.buttonModify_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.BackColor = System.Drawing.Color.MistyRose;
            this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCancel.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCancel.Location = new System.Drawing.Point(241, 359);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(150, 52);
            this.buttonCancel.TabIndex = 9;
            this.buttonCancel.Text = "Cancel Appointment";
            this.buttonCancel.UseVisualStyleBackColor = false;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // buttonBook
            // 
            this.buttonBook.BackColor = System.Drawing.Color.MistyRose;
            this.buttonBook.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBook.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBook.Location = new System.Drawing.Point(75, 359);
            this.buttonBook.Name = "buttonBook";
            this.buttonBook.Size = new System.Drawing.Size(144, 52);
            this.buttonBook.TabIndex = 8;
            this.buttonBook.Text = "Book Appointment";
            this.buttonBook.UseVisualStyleBackColor = false;
            this.buttonBook.Click += new System.EventHandler(this.buttonBook_Click);
            // 
            // dataGridViewAppointments
            // 
            this.dataGridViewAppointments.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewAppointments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAppointments.Location = new System.Drawing.Point(62, 110);
            this.dataGridViewAppointments.Name = "dataGridViewAppointments";
            this.dataGridViewAppointments.Size = new System.Drawing.Size(677, 213);
            this.dataGridViewAppointments.TabIndex = 7;
            // 
            // buttonCompleteAppointment
            // 
            this.buttonCompleteAppointment.BackColor = System.Drawing.Color.MistyRose;
            this.buttonCompleteAppointment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCompleteAppointment.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCompleteAppointment.Location = new System.Drawing.Point(575, 359);
            this.buttonCompleteAppointment.Name = "buttonCompleteAppointment";
            this.buttonCompleteAppointment.Size = new System.Drawing.Size(164, 52);
            this.buttonCompleteAppointment.TabIndex = 13;
            this.buttonCompleteAppointment.Text = "Complete Appointment";
            this.buttonCompleteAppointment.UseVisualStyleBackColor = false;
            this.buttonCompleteAppointment.Click += new System.EventHandler(this.buttonCompleteAppointment_Click);
            // 
            // buttonViewMyAppointments
            // 
            this.buttonViewMyAppointments.BackColor = System.Drawing.Color.MistyRose;
            this.buttonViewMyAppointments.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonViewMyAppointments.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonViewMyAppointments.Location = new System.Drawing.Point(315, 469);
            this.buttonViewMyAppointments.Name = "buttonViewMyAppointments";
            this.buttonViewMyAppointments.Size = new System.Drawing.Size(175, 52);
            this.buttonViewMyAppointments.TabIndex = 23;
            this.buttonViewMyAppointments.Text = "View My Appointments";
            this.buttonViewMyAppointments.UseVisualStyleBackColor = false;
            this.buttonViewMyAppointments.Click += new System.EventHandler(this.buttonViewMyAppointments_Click);
            // 
            // textBoxName
            // 
            this.textBoxName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxName.Location = new System.Drawing.Point(290, 430);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(324, 22);
            this.textBoxName.TabIndex = 20;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName.Location = new System.Drawing.Point(170, 427);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(114, 26);
            this.labelName.TabIndex = 19;
            this.labelName.Text = "Enter your name:";
            // 
            // StylistAppointments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 591);
            this.Controls.Add(this.buttonViewMyAppointments);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.buttonCompleteAppointment);
            this.Controls.Add(this.labelTableHeader);
            this.Controls.Add(this.buttonModify);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonBook);
            this.Controls.Add(this.dataGridViewAppointments);
            this.Name = "StylistAppointments";
            this.Text = "Booked Appointments";
            this.Load += new System.EventHandler(this.StylistAppointments_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAppointments)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labelTableHeader;
        private System.Windows.Forms.Button buttonModify;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Button buttonBook;
        private System.Windows.Forms.DataGridView dataGridViewAppointments;
        private System.Windows.Forms.Button buttonCompleteAppointment;
        private System.Windows.Forms.Button buttonViewMyAppointments;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.Label labelName;
    }
}
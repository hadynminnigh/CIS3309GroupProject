﻿namespace HairSalon
{
    partial class RecMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonViewAppointments = new System.Windows.Forms.Button();
            this.buttonViewSchedules = new System.Windows.Forms.Button();
            this.buttonSearchProducts = new System.Windows.Forms.Button();
            this.buttonMakePayment = new System.Windows.Forms.Button();
            this.labelWelcomeMessage = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonViewAppointments
            // 
            this.buttonViewAppointments.BackColor = System.Drawing.Color.MistyRose;
            this.buttonViewAppointments.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonViewAppointments.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonViewAppointments.Location = new System.Drawing.Point(64, 201);
            this.buttonViewAppointments.Name = "buttonViewAppointments";
            this.buttonViewAppointments.Size = new System.Drawing.Size(150, 64);
            this.buttonViewAppointments.TabIndex = 0;
            this.buttonViewAppointments.Text = "View Appointments";
            this.buttonViewAppointments.UseVisualStyleBackColor = false;
            this.buttonViewAppointments.Click += new System.EventHandler(this.buttonViewAppointments_Click);
            // 
            // buttonViewSchedules
            // 
            this.buttonViewSchedules.BackColor = System.Drawing.Color.MistyRose;
            this.buttonViewSchedules.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonViewSchedules.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonViewSchedules.Location = new System.Drawing.Point(234, 201);
            this.buttonViewSchedules.Name = "buttonViewSchedules";
            this.buttonViewSchedules.Size = new System.Drawing.Size(150, 64);
            this.buttonViewSchedules.TabIndex = 1;
            this.buttonViewSchedules.Text = "View Schedules";
            this.buttonViewSchedules.UseVisualStyleBackColor = false;
            this.buttonViewSchedules.Click += new System.EventHandler(this.buttonViewSchedules_Click);
            // 
            // buttonSearchProducts
            // 
            this.buttonSearchProducts.BackColor = System.Drawing.Color.MistyRose;
            this.buttonSearchProducts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSearchProducts.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSearchProducts.Location = new System.Drawing.Point(407, 201);
            this.buttonSearchProducts.Name = "buttonSearchProducts";
            this.buttonSearchProducts.Size = new System.Drawing.Size(150, 64);
            this.buttonSearchProducts.TabIndex = 2;
            this.buttonSearchProducts.Text = "Search Products";
            this.buttonSearchProducts.UseVisualStyleBackColor = false;
            this.buttonSearchProducts.Click += new System.EventHandler(this.buttonSearchProducts_Click);
            // 
            // buttonMakePayment
            // 
            this.buttonMakePayment.BackColor = System.Drawing.Color.MistyRose;
            this.buttonMakePayment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMakePayment.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMakePayment.Location = new System.Drawing.Point(578, 201);
            this.buttonMakePayment.Name = "buttonMakePayment";
            this.buttonMakePayment.Size = new System.Drawing.Size(150, 64);
            this.buttonMakePayment.TabIndex = 3;
            this.buttonMakePayment.Text = "Make Payment";
            this.buttonMakePayment.UseVisualStyleBackColor = false;
            this.buttonMakePayment.Click += new System.EventHandler(this.buttonMakePayment_Click);
            // 
            // labelWelcomeMessage
            // 
            this.labelWelcomeMessage.AutoSize = true;
            this.labelWelcomeMessage.Font = new System.Drawing.Font("Palanquin Dark Medium", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelWelcomeMessage.Location = new System.Drawing.Point(308, 94);
            this.labelWelcomeMessage.Name = "labelWelcomeMessage";
            this.labelWelcomeMessage.Size = new System.Drawing.Size(167, 55);
            this.labelWelcomeMessage.TabIndex = 4;
            this.labelWelcomeMessage.Text = "Welcome!";
            // 
            // RecMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labelWelcomeMessage);
            this.Controls.Add(this.buttonMakePayment);
            this.Controls.Add(this.buttonSearchProducts);
            this.Controls.Add(this.buttonViewSchedules);
            this.Controls.Add(this.buttonViewAppointments);
            this.Name = "RecMenu";
            this.Text = "Menu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonViewAppointments;
        private System.Windows.Forms.Button buttonViewSchedules;
        private System.Windows.Forms.Button buttonSearchProducts;
        private System.Windows.Forms.Button buttonMakePayment;
        private System.Windows.Forms.Label labelWelcomeMessage;
    }
}


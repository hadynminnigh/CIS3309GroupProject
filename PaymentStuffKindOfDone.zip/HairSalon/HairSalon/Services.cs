﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HairSalon // hadyn edit
{
    internal class Services
    {
        public double curlyCut = 100;
        public double touchUp = 50;
        public double highlights = 80;
        public double balayage = 150;
        public double fullColor = 100;
        public double colorConsultation = 0;
        public double cutAndWash = 120;
        public double cut = 100;
        public double perm = 80;
        public double blowOut = 50;
        public double extensions = 150;

        public double FindPrice(string service)
        {
            if (service == "CurlyCut")
            { 
                return curlyCut; 
            }
            else if (service == "TouchUp")
            { 
                return touchUp; 
            }
            else if (service == "Highlights")
            { 
                return highlights; 
            }
            else if (service == "Balayage")
            { 
                return balayage; 
            }
            else if (service == "FullColor")
            { 
                return fullColor; 
            }
            else if (service == "ColorConsultation")
            { 
                return colorConsultation; 
            }
            else if (service == "CutAndWash")
            { 
                return cutAndWash;
            }
            else if (service == "Cut")
            { 
                return cut; 
            }
            else if (service == "Perm")
            { 
                return perm; 
            }
            else if (service == "BlowOut")
            { 
                return blowOut; 
            }
            else if (service == "Extensions")
            { 
                return extensions; 
            }
            else
            { 
                return 0; 
            }



        }
    }

}

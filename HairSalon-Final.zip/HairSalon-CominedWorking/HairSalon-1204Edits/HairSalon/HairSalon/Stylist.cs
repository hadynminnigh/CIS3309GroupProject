﻿using Microsoft.SqlServer.Server;

public class Stylist
{
    private string name;
    private bool mwf;
    private bool tuth;
    private bool cut;
    private bool cutandwash;
    private bool blowout;
    private bool perm;
    private bool highlights;
    private bool balayage;
    private bool touchup;
    private bool fullcolor;
    private bool extensions;
    private int empID;
    private bool curlycut;
    private bool colorconsultation;
    private string about;
    private string photo;

    public string Name
    {
        get { return name; }
        set { name = value; }
    }

    public bool MWF
    {
        get { return mwf; }
        set { mwf = value; }
    }

    public bool Tuth
    {
        get { return tuth; }
        set { tuth = value; }
    }

    public bool Cut
    {
        get { return cut; }
        set { cut = value; }
    }

    public bool Cutandwash
    {
        get { return cutandwash; }
        set { cutandwash = value; }
    }

    public bool Extensions
    {
        get { return extensions; }
        set { extensions = value; }
    }

    public bool Highlights
    {
        get { return highlights; }
        set { highlights = value; }
    }

    public bool Balayage
    {
        get { return balayage; }
        set { balayage = value; }
    }

    public bool TouchUp
    {
        get { return touchup; }
        set { touchup = value; }
    }

    public bool Perm
    {
        get { return perm; }
        set { perm = value; }
    }

    public bool Blowout
    {
        get { return blowout; }
        set { blowout = value; }
    }

    public int EmpID
    {
        get { return empID; }
        set { empID = value; }
    }

    public bool Curlycut
    {
        get { return curlycut; }
        set { curlycut = value; }
    }

    public bool FullColor
    {
        get { return fullcolor; }
        set { fullcolor = value; }
    }

    public bool ColorConsultation
    {
        get { return colorconsultation; }
        set { colorconsultation = value; }
    }
    
    public string About
    {
        get { return about; }
        set { about = value; }
    }

    public string Photo
    {
        get { return photo; }
        set { about = value; }
    }



    public Stylist(string name, bool mwf, bool tuth, bool cut, bool cutandwash, bool extensions, bool highlights, bool balayage, bool touchUp, bool perm, bool blowout, bool curlycut, bool fullColor, bool colorconsultation, int empID, string about, string photo)
    {
        Name = name;
        MWF = mwf;
        Tuth = tuth;
        Cut = cut;
        Cutandwash = cutandwash;
        Extensions = extensions;
        Highlights = highlights;
        Balayage = balayage;
        TouchUp = touchUp;
        Perm = perm;
        Blowout = blowout;
        Curlycut = curlycut;
        FullColor = fullColor;
        ColorConsultation = colorconsultation;
        EmpID = empID;
        About = about;
        Photo = photo;
    }
}

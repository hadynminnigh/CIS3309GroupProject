﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{
    public partial class Products : Form
    {
        DBManager db;
        public Products()
        {
            db = new DBManager();
            InitializeComponent();
        }

        private void LoadProducts()
        {
            DBManager manager = new DBManager();

            try
            {
                DataTable products = manager.GetProducts();
                dataGridViewProducts.DataSource = products;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was an error: " + ex.Message);
            }
        }
        private void Products_Load(object sender, EventArgs e)
        {
            DBManager manager = new DBManager();

            try
            {
                DataTable products = manager.GetProducts();
                dataGridViewProducts.DataSource = products;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was an error: " + ex.Message);
            }
        }

        private void buttonReserve_Click(object sender, EventArgs e)
        {
            ReserveSelectedItem();
            LoadProducts();
           
        }
        private void ReserveSelectedItem()
        {
            if (dataGridViewProducts.SelectedRows.Count > 0)
            {
              
                string itemName = dataGridViewProducts.SelectedRows[0].Cells["Item"].Value.ToString();

                db.ReserveProduct(itemName);
            }
            else
            {
                MessageBox.Show("Please select an item to reserve.");
            }
        }
        private void UnreserveSelectedItem()
        {
            if (dataGridViewProducts.SelectedRows.Count > 0)
            {

                string itemName = dataGridViewProducts.SelectedRows[0].Cells["Item"].Value.ToString();

                db.UnreserveProduct(itemName);
            }
            else
            {
                MessageBox.Show("Please select an item to unreserve.");
            }
        }


        private void dataGridViewProducts_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void buttonUnreserve_Click(object sender, EventArgs e)
        {
            UnreserveSelectedItem();
            LoadProducts();
        }
    }
}

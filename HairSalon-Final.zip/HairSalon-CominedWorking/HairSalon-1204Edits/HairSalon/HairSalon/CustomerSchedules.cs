﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{
    public partial class CustomerSchedules : Form
    {
        DBManager db;
        public CustomerSchedules()
        {
            InitializeComponent();
            db = new DBManager();

        }

        private void dataGridViewSchedule_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void LoadSchedules()
        {
            DataTable stylists = db.GetSchedule();
            dataGridViewSchedule.DataSource = stylists;
        }

        private void CustomerSchedules_Load(object sender, EventArgs e)
        {
            LoadSchedules();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedStylist = comboBox1.SelectedItem.ToString();


            DataTable allSchedules = db.GetSchedule();

            DataView filteredView = new DataView(allSchedules);
            filteredView.RowFilter = $"StylistName = '{selectedStylist}'";

            dataGridViewSchedule.DataSource = filteredView;

            LoadStylistInfo(selectedStylist);
        }
        private void LoadStylistInfo(string stylistName)
        {

            List<Stylist> stylists = db.GetStylistsByName(stylistName);

           
                Stylist stylist = stylists[0];
                txtAbout.Text = stylist.About;
            }

            // only shows stylist name adn days available
            // displays picture and the services they provide
            // when one is clicked on
        }
    }



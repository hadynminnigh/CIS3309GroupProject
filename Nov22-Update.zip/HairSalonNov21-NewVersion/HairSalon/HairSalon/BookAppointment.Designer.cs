﻿namespace HairSalon
{
    partial class BookAppointment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxCustomerInfo = new System.Windows.Forms.GroupBox();
            this.cboService = new System.Windows.Forms.ComboBox();
            this.cboThickness = new System.Windows.Forms.ComboBox();
            this.cboHairType = new System.Windows.Forms.ComboBox();
            this.txtPhoneNumber = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.lblThickness = new System.Windows.Forms.Label();
            this.lblService = new System.Windows.Forms.Label();
            this.lblHairType = new System.Windows.Forms.Label();
            this.lblPhoneNumber = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.groupBoxPossibleApt = new System.Windows.Forms.GroupBox();
            this.dataGridViewBookApts = new System.Windows.Forms.DataGridView();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.lblStylistSelect = new System.Windows.Forms.Label();
            this.cboStylist = new System.Windows.Forms.ComboBox();
            this.btnBookAppoitment = new System.Windows.Forms.Button();
            this.groupBoxCustomerInfo.SuspendLayout();
            this.groupBoxPossibleApt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBookApts)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxCustomerInfo
            // 
            this.groupBoxCustomerInfo.Controls.Add(this.cboStylist);
            this.groupBoxCustomerInfo.Controls.Add(this.lblStylistSelect);
            this.groupBoxCustomerInfo.Controls.Add(this.cboService);
            this.groupBoxCustomerInfo.Controls.Add(this.cboThickness);
            this.groupBoxCustomerInfo.Controls.Add(this.cboHairType);
            this.groupBoxCustomerInfo.Controls.Add(this.txtPhoneNumber);
            this.groupBoxCustomerInfo.Controls.Add(this.txtEmail);
            this.groupBoxCustomerInfo.Controls.Add(this.txtLastName);
            this.groupBoxCustomerInfo.Controls.Add(this.txtFirstName);
            this.groupBoxCustomerInfo.Controls.Add(this.lblThickness);
            this.groupBoxCustomerInfo.Controls.Add(this.lblService);
            this.groupBoxCustomerInfo.Controls.Add(this.lblHairType);
            this.groupBoxCustomerInfo.Controls.Add(this.lblPhoneNumber);
            this.groupBoxCustomerInfo.Controls.Add(this.lblEmail);
            this.groupBoxCustomerInfo.Controls.Add(this.lblLastName);
            this.groupBoxCustomerInfo.Controls.Add(this.lblFirstName);
            this.groupBoxCustomerInfo.Location = new System.Drawing.Point(13, 13);
            this.groupBoxCustomerInfo.Name = "groupBoxCustomerInfo";
            this.groupBoxCustomerInfo.Size = new System.Drawing.Size(343, 373);
            this.groupBoxCustomerInfo.TabIndex = 0;
            this.groupBoxCustomerInfo.TabStop = false;
            this.groupBoxCustomerInfo.Text = "Customer Info";
            // 
            // cboService
            // 
            this.cboService.FormattingEnabled = true;
            this.cboService.Items.AddRange(new object[] {
            "Cut ",
            "Cut and Wash(includdes vlow dry)",
            "Curly Cut",
            "Blowout",
            "Perm",
            "Blow Out",
            "Highlighs",
            "Balayage",
            "Touch Up",
            "Full Color",
            "Color Consultation",
            "Extensions"});
            this.cboService.Location = new System.Drawing.Point(6, 250);
            this.cboService.Name = "cboService";
            this.cboService.Size = new System.Drawing.Size(121, 21);
            this.cboService.TabIndex = 21;
            // 
            // cboThickness
            // 
            this.cboThickness.FormattingEnabled = true;
            this.cboThickness.Items.AddRange(new object[] {
            "Thin",
            "Medium",
            "Thick"});
            this.cboThickness.Location = new System.Drawing.Point(6, 210);
            this.cboThickness.Name = "cboThickness";
            this.cboThickness.Size = new System.Drawing.Size(121, 21);
            this.cboThickness.TabIndex = 20;
            // 
            // cboHairType
            // 
            this.cboHairType.FormattingEnabled = true;
            this.cboHairType.Items.AddRange(new object[] {
            "Straight",
            "Curly",
            "Wavy"});
            this.cboHairType.Location = new System.Drawing.Point(6, 161);
            this.cboHairType.Name = "cboHairType";
            this.cboHairType.Size = new System.Drawing.Size(121, 21);
            this.cboHairType.TabIndex = 17;
            // 
            // txtPhoneNumber
            // 
            this.txtPhoneNumber.Location = new System.Drawing.Point(93, 116);
            this.txtPhoneNumber.Name = "txtPhoneNumber";
            this.txtPhoneNumber.Size = new System.Drawing.Size(100, 20);
            this.txtPhoneNumber.TabIndex = 16;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(48, 87);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(100, 20);
            this.txtEmail.TabIndex = 15;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(73, 59);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(100, 20);
            this.txtLastName.TabIndex = 14;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(73, 33);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(100, 20);
            this.txtFirstName.TabIndex = 13;
            // 
            // lblThickness
            // 
            this.lblThickness.AutoSize = true;
            this.lblThickness.Location = new System.Drawing.Point(6, 194);
            this.lblThickness.Name = "lblThickness";
            this.lblThickness.Size = new System.Drawing.Size(81, 13);
            this.lblThickness.TabIndex = 11;
            this.lblThickness.Text = "Hair Thickness:";
            // 
            // lblService
            // 
            this.lblService.AutoSize = true;
            this.lblService.Location = new System.Drawing.Point(7, 234);
            this.lblService.Name = "lblService";
            this.lblService.Size = new System.Drawing.Size(46, 13);
            this.lblService.TabIndex = 5;
            this.lblService.Text = "Service:";
            this.lblService.Click += new System.EventHandler(this.lblService_Click);
            // 
            // lblHairType
            // 
            this.lblHairType.AutoSize = true;
            this.lblHairType.Location = new System.Drawing.Point(6, 145);
            this.lblHairType.Name = "lblHairType";
            this.lblHairType.Size = new System.Drawing.Size(56, 13);
            this.lblHairType.TabIndex = 4;
            this.lblHairType.Text = "Hair Type:";
            // 
            // lblPhoneNumber
            // 
            this.lblPhoneNumber.AutoSize = true;
            this.lblPhoneNumber.Location = new System.Drawing.Point(6, 119);
            this.lblPhoneNumber.Name = "lblPhoneNumber";
            this.lblPhoneNumber.Size = new System.Drawing.Size(81, 13);
            this.lblPhoneNumber.TabIndex = 3;
            this.lblPhoneNumber.Text = "Phone Number:";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(7, 90);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(35, 13);
            this.lblEmail.TabIndex = 2;
            this.lblEmail.Text = "Email:";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(6, 62);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(61, 13);
            this.lblLastName.TabIndex = 1;
            this.lblLastName.Text = "Last Name:";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(7, 37);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(60, 13);
            this.lblFirstName.TabIndex = 0;
            this.lblFirstName.Text = "First Name:";
            // 
            // groupBoxPossibleApt
            // 
            this.groupBoxPossibleApt.Controls.Add(this.dataGridViewBookApts);
            this.groupBoxPossibleApt.Location = new System.Drawing.Point(373, 13);
            this.groupBoxPossibleApt.Name = "groupBoxPossibleApt";
            this.groupBoxPossibleApt.Size = new System.Drawing.Size(415, 310);
            this.groupBoxPossibleApt.TabIndex = 1;
            this.groupBoxPossibleApt.TabStop = false;
            this.groupBoxPossibleApt.Text = "Possible Appoitments";
            // 
            // dataGridViewBookApts
            // 
            this.dataGridViewBookApts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBookApts.Location = new System.Drawing.Point(17, 20);
            this.dataGridViewBookApts.Name = "dataGridViewBookApts";
            this.dataGridViewBookApts.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewBookApts.Size = new System.Drawing.Size(392, 278);
            this.dataGridViewBookApts.TabIndex = 0;
            // 
            // lblStylistSelect
            // 
            this.lblStylistSelect.AutoSize = true;
            this.lblStylistSelect.Location = new System.Drawing.Point(7, 274);
            this.lblStylistSelect.Name = "lblStylistSelect";
            this.lblStylistSelect.Size = new System.Drawing.Size(37, 13);
            this.lblStylistSelect.TabIndex = 22;
            this.lblStylistSelect.Text = "Stylist:";
            // 
            // cboStylist
            // 
            this.cboStylist.FormattingEnabled = true;
            this.cboStylist.Items.AddRange(new object[] {
            "Any",
            "Martha"});
            this.cboStylist.Location = new System.Drawing.Point(6, 290);
            this.cboStylist.Name = "cboStylist";
            this.cboStylist.Size = new System.Drawing.Size(121, 21);
            this.cboStylist.TabIndex = 23;
            // 
            // btnBookAppoitment
            // 
            this.btnBookAppoitment.Location = new System.Drawing.Point(373, 339);
            this.btnBookAppoitment.Name = "btnBookAppoitment";
            this.btnBookAppoitment.Size = new System.Drawing.Size(215, 64);
            this.btnBookAppoitment.TabIndex = 3;
            this.btnBookAppoitment.Text = "Book Appoitment";
            this.btnBookAppoitment.UseVisualStyleBackColor = true;
            this.btnBookAppoitment.Click += new System.EventHandler(this.btnBookAppoitment_Click_1);
            // 
            // BookAppointment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnBookAppoitment);
            this.Controls.Add(this.groupBoxPossibleApt);
            this.Controls.Add(this.groupBoxCustomerInfo);
            this.Name = "BookAppointment";
            this.Text = "BookAppointment";
            this.Load += new System.EventHandler(this.BookAppointment_Load);
            this.groupBoxCustomerInfo.ResumeLayout(false);
            this.groupBoxCustomerInfo.PerformLayout();
            this.groupBoxPossibleApt.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBookApts)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxCustomerInfo;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblService;
        private System.Windows.Forms.Label lblHairType;
        private System.Windows.Forms.Label lblPhoneNumber;
        private System.Windows.Forms.ComboBox cboHairType;
        private System.Windows.Forms.TextBox txtPhoneNumber;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label lblThickness;
        private System.Windows.Forms.ComboBox cboService;
        private System.Windows.Forms.ComboBox cboThickness;
        private System.Windows.Forms.GroupBox groupBoxPossibleApt;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.DataGridView dataGridViewBookApts;
        private System.Windows.Forms.ComboBox cboStylist;
        private System.Windows.Forms.Label lblStylistSelect;
        private System.Windows.Forms.Button btnBookAppoitment;
    }
}
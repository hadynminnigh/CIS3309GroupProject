﻿using HairSalon;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Runtime.Remoting.Messaging;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace ClassesForProject
{
    internal class Stylist

    {

        private string name;
        private string services;
        private bool mwf;
        private bool tuth;
        private bool cut;
        private bool cutandwash;
        private bool blowout;
        private bool perm;
        private bool highlights;
        private bool balayage;
        private bool touchup;
        private bool fullcolor;
        private bool extensions;
        private int empID;
        private bool curlycut;
        private bool colorconsultation;

    ////will get total pay, expected pay, etc from other class and display in database

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
     

        public bool MWF
        {
            get { return mwf; }
            set { mwf = value; }
        }
        public bool Tuth
        {
            get { return tuth; }
            set { tuth = value; }
        }
        public bool Cut
        {
            get { return cut; }
            set { cut = value; }
        }
        public bool Cutandwash
        {
            get { return cutandwash; }
            set { cutandwash = value; }
        }
        public bool Extensions
        {
            get { return extensions; }
            set { extensions = value; }
        }
        public bool Highlights
        {
            get { return highlights; }
            set { highlights = value; }
        }
        public bool Balayage
        {
            get { return balayage; }
            set { balayage = value; }
        }
        public bool TouchUp
        {
            get { return touchup; }
            set { touchup = value; }
        }
        public bool Perm
        {
            get { return perm; }
            set { perm = value; }
        }
        public bool Blowout
        {
            get { return blowout; }
            set { blowout = value; }
        }
        public int EmpID
        {
            get { return EmpID; }
            set { EmpID = value; }
        }
        public bool Curlycut
        {
            get { return curlycut; }
            set { curlycut = value; }
        }
        public bool FullColor
        {
            get { return fullcolor; }
            set { fullcolor = value; }
        }
        public bool ColorConsultation
        {
            get { return colorconsultation; }
            set { colorconsultation = value; }
        }


       

        public Stylist(string name, bool mWF, bool tuth, bool cut, bool cutandwash, bool extensions, bool highlights, bool balayage, bool touchUp, bool perm, bool blowout, bool curlycut, bool fullColor, bool colorconsultation, int empID)
        {
            Name = name;
            MWF = mWF;
            Tuth = tuth;
            Cut = cut;
            Cutandwash = cutandwash;
            Extensions = extensions;
            Highlights = highlights;
            Balayage = balayage;
            TouchUp = touchUp;
            Perm = perm;
            Blowout = blowout;
            Curlycut = curlycut;
            FullColor = fullColor;
            ColorConsultation = colorconsultation;
            EmpID = empID;
            
        }
        public static class AllStylist
        {
            public static List<Stylist> AllStylists = new List<Stylist>();
        }
    }
}

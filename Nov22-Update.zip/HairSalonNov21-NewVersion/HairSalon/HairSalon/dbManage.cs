﻿using ClassesForProject;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace HairSalon
{
    internal class dbManage
    {
        string connection = "provider=Microsoft.ACE.OLEDB.12.0;" + @"Data Source=HairSalon.accdb;";

        OleDbConnection myConnection;
        DataSet dataSet;
        DataSet StylistdataSet;
        OleDbDataAdapter dataAdapter;
        OleDbCommandBuilder commandBuilder;
        OleDbDataAdapter StylistdataAdapter;

        public dbManage()
        {
            myConnection = new OleDbConnection(connection);
            dataSet = new DataSet();

            dataAdapter = new OleDbDataAdapter("SELECT * FROM Appointments", myConnection);
            commandBuilder = new OleDbCommandBuilder(dataAdapter);
            dataAdapter.Fill(dataSet, "Appointments");

            StylistdataAdapter = new OleDbDataAdapter("SELECT * FROM Stylists", myConnection);
            commandBuilder = new OleDbCommandBuilder(StylistdataAdapter);
            StylistdataAdapter.Fill(StylistdataSet, "Stylist");

        }

        public List<Appointment> GetAppointments()
        {

            List<Appointment> appointments = new List<Appointment>();

            foreach (DataRow row in dataSet.Tables["Appointments"].Rows)
            {
                Appointment appointment = new Appointment(
                    row["CustomerName"].ToString(),
                    row["Email"].ToString(),
                    row["Phonenumber"].ToString(),
                    row["Hairtype"].ToString(),
                    row["Thickness"].ToString(),
                    row["Service"].ToString(),
                    row["Stylist"].ToString(),
                    DateTime.Parse(row["AptDate"].ToString()),
                    int.Parse(row["CardInfo"].ToString())
                    );
                
                appointments.Add(appointment);
            }

            return appointments;
        }
        public List<Stylist> GetStylists()
        {
            List<Stylist> stylists = new List<Stylist>();
            foreach (DataRow row in dataSet.Tables["Stylists"].Rows)
            {
                Stylist stylist = new Stylist
                    (
                    row["Name"].ToString(),
                    bool.Parse(row["MWF"].ToString()),
                    bool.Parse(row["TuTh"].ToString()),
                    bool.Parse(row["Cut"].ToString()),
                    bool.Parse(row["CutandWash"].ToString()),
                    bool.Parse(row["Extensions"].ToString()),
                    bool.Parse(row["Highlights"].ToString()),
                    bool.Parse(row["Balayage"].ToString()),
                    bool.Parse(row["TouchUp"].ToString()),   
                    bool.Parse(row["Perm"].ToString()),
                    bool.Parse(row["BlowOut"].ToString()),
                    bool.Parse(row["CurlyCut"].ToString()),
                    bool.Parse(row["FullColor"].ToString()),
                    bool.Parse(row["ColorConsultation"].ToString()),
                    int.Parse(row["EmployeeID"].ToString())

                    );
                stylists.Add(stylist);
            }
            return stylists;
        }
        public void BookAppointment(Appointment appointment)
        {
            DataRow newRow = dataSet.Tables["Appointments"].NewRow();
            newRow["CustomerName"] = appointment.CustomerName;
            newRow["Email"] = appointment.Email;
            newRow["Phonenumber"] = appointment.Phonenumber;
            newRow["Hairtype"] = appointment.Hairtype;
            newRow["HairThickness"] = appointment.Thickness;
            newRow["Service"] = appointment.Service;
            newRow["Stylist"] = appointment.StylistName;

            dataSet.Tables["Appointments"].Rows.Add(newRow);

            dataAdapter.InsertCommand = commandBuilder.GetInsertCommand();
            Update();


        }

        public void Update()
        {
            myConnection.Open();
            dataAdapter.Update(dataSet, "Appointments");
            myConnection.Close();
        }
        //add a get stylist method. also make get methods for all the services to get the stlyidt name
        //so that way we can have s if check to hae the right stylst show up in the cbo box.


    }
}
﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace HairSalon
{

    internal class DBManager
    {
        string connection = "Provider=Microsoft.ACE.OLEDB.12.0;" +
                                      "Data Source=HairSalonDB.accdb;";
        OleDbConnection myConnection;
        DataSet dataSet;
        DataSet StylistdataSet;
        OleDbDataAdapter dataAdapter;
        OleDbCommandBuilder commandBuilder;
        OleDbDataAdapter StylistdataAdapter;

        public DBManager()
        {
            myConnection = new OleDbConnection(connection);
            dataSet = new DataSet();

            dataAdapter = new OleDbDataAdapter("SELECT * FROM Appointments", myConnection);
            commandBuilder = new OleDbCommandBuilder(dataAdapter);
            dataAdapter.Fill(dataSet, "Appointments");
            myConnection = new OleDbConnection(connection);
            dataSet = new DataSet();

            dataAdapter = new OleDbDataAdapter("SELECT * FROM Appointments", myConnection);
            commandBuilder = new OleDbCommandBuilder(dataAdapter);
            dataAdapter.Fill(dataSet, "Appointments");


            LoadStylistsData();



        }
        public bool CheckLogin(string username, string password)
        {
            bool loginCorrect = false;

            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" +
                                      "Data Source=HairSalonDB.accdb;";

            string selectSql = "SELECT * FROM logins " +
                               "WHERE Username = '" + username + "' " +
                               "AND Password = '" + password + "'";

            OleDbConnection myConnection = new OleDbConnection(connectionString);
            OleDbCommand myCommand = new OleDbCommand(selectSql, myConnection);
            OleDbDataReader myDataReader;
            List<string> logins = new List<string>();

            try
            {
                myConnection.Open();
                myDataReader = myCommand.ExecuteReader();

                while (myDataReader.Read())
                {
                    string user = myDataReader["Username"].ToString();
                    logins.Add(user);
                }
            }
            catch (OleDbException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                myConnection.Close();
            }

            if (logins.Count == 0)
            {
                Console.WriteLine("Nothing was found " + logins);
            }
            else
            {
                loginCorrect = true;
            }

            return loginCorrect;
        }

        public string AccountType(string username, string password)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" +
                                      "Data Source=HairSalonDB.accdb;";

            string selectSql = "SELECT AccountType FROM logins " +
                               "WHERE Username = '" + username + "' " +
                               "AND Password = '" + password + "'";

            OleDbConnection myConnection = new OleDbConnection(connectionString);
            OleDbCommand myCommand = new OleDbCommand(selectSql, myConnection);
            OleDbDataReader myDataReader;
            List<string> accountType = new List<string>();

            try
            {
                myConnection.Open();
                myDataReader = myCommand.ExecuteReader();

                while (myDataReader.Read())
                {
                    string type = myDataReader["AccountType"].ToString();
                    accountType.Add(type);
                }
            }
            catch (OleDbException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                myConnection.Close();
            }

            if (accountType.Count == 0)
            {
                Console.WriteLine("Nothing was found " + accountType);
                return "Nothing was found";
            }
            else
            {
                return accountType[0];
            }


        }

        public DataTable GetAppointments()
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" +
                                      "Data Source=HairSalonDB.accdb;";

            string selectSql = "SELECT * FROM Appointments";

            OleDbConnection myConnection = new OleDbConnection(connectionString);
            //OleDbCommand myCommand = new OleDbCommand(selectSql, myConnection);
            OleDbDataAdapter myDataAdapter = new OleDbDataAdapter(selectSql, myConnection);
            DataTable appointmentTable = new DataTable();

            try
            {
                myConnection.Open();

                myDataAdapter.Fill(appointmentTable);
            }
            catch (OleDbException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                myConnection.Close();
            }

            return appointmentTable;
        }

        public void BookAppointment(Appointment appointment)
        {
            DataRow newRow = dataSet.Tables["Appointments"].NewRow();
            newRow["FirstName"] = appointment.FirstName;
            newRow["LastName"] = appointment.LastName;
            newRow["Email"] = appointment.Email;
            newRow["Phonenumber"] = appointment.Phonenumber;
            newRow["Hairtype"] = appointment.Hairtype;
            newRow["HairThickness"] = appointment.Thickness;
            newRow["Service"] = appointment.Service;
            newRow["Stylist"] = appointment.Stylist;

            dataSet.Tables["Appointments"].Rows.Add(newRow);
            dataAdapter.InsertCommand = commandBuilder.GetInsertCommand();
            Update();
        }

        public void Update()
        {
            myConnection.Open();
            dataAdapter.Update(dataSet, "Appointments");
            myConnection.Close();
        }
        public void DeleteAppointment(Appointment appointment)
        {
            //will add this eventually but i wanna do the stylist stuff first
        }
        public void LoadStylistsData()
        {
            string selectSql = "SELECT * FROM Stylists";

            OleDbDataAdapter stylistAdapter = new OleDbDataAdapter(selectSql, myConnection);
            stylistAdapter.Fill(dataSet, "Stylists");
        }

        public List<Stylist> GetStylists()
        {
            List<Stylist> stylists = new List<Stylist>();
            foreach (DataRow row in dataSet.Tables["Stylists"].Rows)
            {
                Stylist stylist = new Stylist(
                    row["Name"].ToString(),
                    Convert.ToBoolean(row["MWF"]),
                    Convert.ToBoolean(row["TuTh"]),
                    Convert.ToBoolean(row["Cut"]),
                    Convert.ToBoolean(row["CutandWash"]),
                    Convert.ToBoolean(row["Extensions"]),
                    Convert.ToBoolean(row["Highlights"]),
                    Convert.ToBoolean(row["Balayage"]),
                    Convert.ToBoolean(row["TouchUp"]),
                    Convert.ToBoolean(row["Perm"]),
                    Convert.ToBoolean(row["BlowOut"]),
                    Convert.ToBoolean(row["CurlyCut"]),
                    Convert.ToBoolean(row["FullColor"]),
                    Convert.ToBoolean(row["ColorConsultation"]),
                    Convert.ToInt32(row["EmployeeID"])
                );
                stylists.Add(stylist);
            }
            return stylists;
        }
        public List<Stylist> GetStylistsByService(string serviceName)
        {
            List<Stylist> stylists = new List<Stylist>();

            foreach (DataRow row in dataSet.Tables["Stylists"].Rows)
            {
                // Check if the stylist provides the requested service
                if (row[serviceName].ToString() == "True")
                {
                    Stylist stylist = new Stylist(
                        row["Name"].ToString(),
                        bool.Parse(row["MWF"].ToString()),
                        bool.Parse(row["TuTh"].ToString()),
                        bool.Parse(row["Cut"].ToString()),
                        bool.Parse(row["CutandWash"].ToString()),
                        bool.Parse(row["Extensions"].ToString()),
                        bool.Parse(row["Highlights"].ToString()),
                        bool.Parse(row["Balayage"].ToString()),
                        bool.Parse(row["TouchUp"].ToString()),
                        bool.Parse(row["Perm"].ToString()),
                        bool.Parse(row["BlowOut"].ToString()),
                        bool.Parse(row["CurlyCut"].ToString()),
                        bool.Parse(row["FullColor"].ToString()),
                        bool.Parse(row["ColorConsultation"].ToString()),
                        int.Parse(row["EmployeeID"].ToString())
                    );

                    stylists.Add(stylist);
                }
            }

            return stylists;
        }

    }
}


//        public List<Stylist> GetStylistsByServiceAndAvailability(string service, string availability)
//        {
//            List<Stylist> stylists = new List<Stylist>();

//            // Check if "Stylists" table exists in the dataset
//            if (dataSet.Tables.Contains("Stylists"))
//            {
//                foreach (DataRow row in dataSet.Tables["Stylists"].Rows)
//                {
//                    // Check if the stylist is available on the specified days (MWF or TuTh)
//                    bool isAvailable = false;

//                    if (availability == "MWF" && bool.Parse(row["MWF"].ToString()))
//                    {
//                        isAvailable = true;
//                    }
//                    else if (availability == "TuTh" && bool.Parse(row["TuTh"].ToString()))
//                    {
//                        isAvailable = true;
//                    }

//                    // Now check if the stylist offers the requested service
//                    bool offersService = false;

//                    switch (service)
//                    {
//                        case "Cut":
//                            offersService = bool.Parse(row["Cut"].ToString());
//                            break;
//                        case "CutandWash":
//                            offersService = bool.Parse(row["CutandWash"].ToString());
//                            break;
//                        case "Extensions":
//                            offersService = bool.Parse(row["Extensions"].ToString());
//                            break;
//                        case "Highlights":
//                            offersService = bool.Parse(row["Highlights"].ToString());
//                            break;
//                        case "Balayage":
//                            offersService = bool.Parse(row["Balayage"].ToString());
//                            break;
//                        case "TouchUp":
//                            offersService = bool.Parse(row["TouchUp"].ToString());
//                            break;
//                        case "Perm":
//                            offersService = bool.Parse(row["Perm"].ToString());
//                            break;
//                        case "BlowOut":
//                            offersService = bool.Parse(row["BlowOut"].ToString());
//                            break;
//                        case "CurlyCut":
//                            offersService = bool.Parse(row["CurlyCut"].ToString());
//                            break;
//                        case "FullColor":
//                            offersService = bool.Parse(row["FullColor"].ToString());
//                            break;
//                        case "ColorConsultation":
//                            offersService = bool.Parse(row["ColorConsultation"].ToString());
//                            break;
//                        default:
//                            break;
//                    }

//                    // If the stylist is available and offers the service, add them to the list
//                    if (isAvailable && offersService)
//                    {
//                        Stylist stylist = new Stylist(
//                            row["Name"].ToString(),
//                            bool.Parse(row["MWF"].ToString()),
//                            bool.Parse(row["TuTh"].ToString()),
//                            bool.Parse(row["Cut"].ToString()),
//                            bool.Parse(row["CutandWash"].ToString()),
//                            bool.Parse(row["Extensions"].ToString()),
//                            bool.Parse(row["Highlights"].ToString()),
//                            bool.Parse(row["Balayage"].ToString()),
//                            bool.Parse(row["TouchUp"].ToString()),
//                            bool.Parse(row["Perm"].ToString()),
//                            bool.Parse(row["BlowOut"].ToString()),
//                            bool.Parse(row["CurlyCut"].ToString()),
//                            bool.Parse(row["FullColor"].ToString()),
//                            bool.Parse(row["ColorConsultation"].ToString()),
//                            int.Parse(row["EmployeeID"].ToString())
//                        );

//                        stylists.Add(stylist);
//                    }
//                }
//            }
//            else
//            {
//                // Handle the case where the "Stylists" table is not found
//                MessageBox.Show("The Stylists table could not be found.");
//            }

//            return stylists;
//        }


//    }
//}
//public List<Stylist> GetStylistsByAvailability(string availability)
//{
//    List<Stylist> stylists = new List<Stylist>();

//    foreach (DataRow row in dataSet.Tables["Stylists"].Rows)
//    {
//        // Check if the stylist is available on the specified days
//        if (availability == "MWF" && bool.Parse(row["MWF"].ToString()))
//        {
//            Stylist stylist = new Stylist(
//                row["Name"].ToString(),
//                bool.Parse(row["MWF"].ToString()),
//                bool.Parse(row["TuTh"].ToString()),
//                bool.Parse(row["Cut"].ToString()),
//                bool.Parse(row["CutandWash"].ToString()),
//                bool.Parse(row["Extensions"].ToString()),
//                bool.Parse(row["Highlights"].ToString()),
//                bool.Parse(row["Balayage"].ToString()),
//                bool.Parse(row["TouchUp"].ToString()),
//                bool.Parse(row["Perm"].ToString()),
//                bool.Parse(row["BlowOut"].ToString()),
//                bool.Parse(row["CurlyCut"].ToString()),
//                bool.Parse(row["FullColor"].ToString()),
//                bool.Parse(row["ColorConsultation"].ToString()),
//                int.Parse(row["EmployeeID"].ToString())
//            );
//            stylists.Add(stylist);
//        }
//        else if (availability == "TuTh" && bool.Parse(row["TuTh"].ToString()))
//        {
//            Stylist stylist = new Stylist(
//                row["Name"].ToString(),
//                bool.Parse(row["MWF"].ToString()),
//                bool.Parse(row["TuTh"].ToString()),
//                bool.Parse(row["Cut"].ToString()),
//                bool.Parse(row["CutandWash"].ToString()),
//                bool.Parse(row["Extensions"].ToString()),
//                bool.Parse(row["Highlights"].ToString()),
//                bool.Parse(row["Balayage"].ToString()),
//                bool.Parse(row["TouchUp"].ToString()),
//                bool.Parse(row["Perm"].ToString()),
//                bool.Parse(row["BlowOut"].ToString()),
//                bool.Parse(row["CurlyCut"].ToString()),
//                bool.Parse(row["FullColor"].ToString()),
//                bool.Parse(row["ColorConsultation"].ToString()),
//                int.Parse(row["EmployeeID"].ToString())
//            );
//            stylists.Add(stylist);
//        }
//    }

//    return stylists;
//}
//private bool IsAvailableOnDay(string availability, DataRow row)
//{
//    if (availability == "MWF" && bool.Parse(row["MWF"].ToString()))
//    {
//        return true;
//    }
//    if (availability == "TuTh" && bool.Parse(row["TuTh"].ToString()))
//    {
//        return true;
//    }
//    return false;
//}
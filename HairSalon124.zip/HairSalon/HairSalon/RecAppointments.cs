﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HairSalon
{
    public partial class RecAppointments : Form
    {
        public RecAppointments()
        {
            InitializeComponent();
            
        }

        private void buttonModify_Click(object sender, EventArgs e)
        {
            ModifyAppointment modifyAppointment = new ModifyAppointment();
            modifyAppointment.ShowDialog();
        }

        private void buttonBook_Click(object sender, EventArgs e)
        {
            BookAppointment bookAppointment = new BookAppointment();
            bookAppointment.ShowDialog();
        }

        private void RecAppointments_Load(object sender, EventArgs e)
        {
            DBManager manager = new DBManager();

            try
            {
                DataTable appointments = manager.GetAppointments();
                dataGridViewAppointments.DataSource = appointments;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was an error: " + ex.Message);
            }
        }

        private void dataGridViewAppointments_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

﻿namespace HairSalon
{
    partial class StylistSchedule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelTableHeader = new System.Windows.Forms.Label();
            this.dataGridViewSchedule = new System.Windows.Forms.DataGridView();
            this.buttonChangeAvailability = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSchedule)).BeginInit();
            this.SuspendLayout();
            // 
            // labelTableHeader
            // 
            this.labelTableHeader.AutoSize = true;
            this.labelTableHeader.Font = new System.Drawing.Font("Palanquin Dark Medium", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTableHeader.Location = new System.Drawing.Point(296, 45);
            this.labelTableHeader.Name = "labelTableHeader";
            this.labelTableHeader.Size = new System.Drawing.Size(200, 55);
            this.labelTableHeader.TabIndex = 14;
            this.labelTableHeader.Text = "My Schedule";
            // 
            // dataGridViewSchedule
            // 
            this.dataGridViewSchedule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSchedule.Location = new System.Drawing.Point(62, 116);
            this.dataGridViewSchedule.Name = "dataGridViewSchedule";
            this.dataGridViewSchedule.Size = new System.Drawing.Size(677, 213);
            this.dataGridViewSchedule.TabIndex = 13;
            // 
            // buttonChangeAvailability
            // 
            this.buttonChangeAvailability.BackColor = System.Drawing.Color.MistyRose;
            this.buttonChangeAvailability.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonChangeAvailability.Font = new System.Drawing.Font("Palanquin Dark", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonChangeAvailability.Location = new System.Drawing.Point(330, 355);
            this.buttonChangeAvailability.Name = "buttonChangeAvailability";
            this.buttonChangeAvailability.Size = new System.Drawing.Size(150, 64);
            this.buttonChangeAvailability.TabIndex = 15;
            this.buttonChangeAvailability.Text = "Change Availability";
            this.buttonChangeAvailability.UseVisualStyleBackColor = false;
            // 
            // StylistSchedule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonChangeAvailability);
            this.Controls.Add(this.labelTableHeader);
            this.Controls.Add(this.dataGridViewSchedule);
            this.Name = "StylistSchedule";
            this.Text = "StylistSchedule";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSchedule)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labelTableHeader;
        private System.Windows.Forms.DataGridView dataGridViewSchedule;
        private System.Windows.Forms.Button buttonChangeAvailability;
    }
}
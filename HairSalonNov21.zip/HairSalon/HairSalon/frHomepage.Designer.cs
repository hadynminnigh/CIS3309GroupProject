﻿namespace HairSalon
{
    partial class frHomepage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBook = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnViewApt = new System.Windows.Forms.Button();
            this.btnModifyApt = new System.Windows.Forms.Button();
            this.btnViewSchedule = new System.Windows.Forms.Button();
            this.btnSearchProducts = new System.Windows.Forms.Button();
            this.btnPayment = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnBook
            // 
            this.btnBook.Location = new System.Drawing.Point(62, 42);
            this.btnBook.Name = "btnBook";
            this.btnBook.Size = new System.Drawing.Size(136, 53);
            this.btnBook.TabIndex = 0;
            this.btnBook.Text = "Book Appoitment";
            this.btnBook.UseVisualStyleBackColor = true;
            this.btnBook.Click += new System.EventHandler(this.btnBook_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(204, 42);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(134, 53);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel Appoitment";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnViewApt
            // 
            this.btnViewApt.Location = new System.Drawing.Point(344, 42);
            this.btnViewApt.Name = "btnViewApt";
            this.btnViewApt.Size = new System.Drawing.Size(136, 54);
            this.btnViewApt.TabIndex = 2;
            this.btnViewApt.Text = "View Appoitments";
            this.btnViewApt.UseVisualStyleBackColor = true;
            // 
            // btnModifyApt
            // 
            this.btnModifyApt.Location = new System.Drawing.Point(486, 42);
            this.btnModifyApt.Name = "btnModifyApt";
            this.btnModifyApt.Size = new System.Drawing.Size(136, 54);
            this.btnModifyApt.TabIndex = 3;
            this.btnModifyApt.Text = "Modify Apoitments";
            this.btnModifyApt.UseVisualStyleBackColor = true;
            // 
            // btnViewSchedule
            // 
            this.btnViewSchedule.Location = new System.Drawing.Point(125, 123);
            this.btnViewSchedule.Name = "btnViewSchedule";
            this.btnViewSchedule.Size = new System.Drawing.Size(136, 48);
            this.btnViewSchedule.TabIndex = 4;
            this.btnViewSchedule.Text = "View Schedule";
            this.btnViewSchedule.UseVisualStyleBackColor = true;
            // 
            // btnSearchProducts
            // 
            this.btnSearchProducts.Location = new System.Drawing.Point(267, 123);
            this.btnSearchProducts.Name = "btnSearchProducts";
            this.btnSearchProducts.Size = new System.Drawing.Size(136, 48);
            this.btnSearchProducts.TabIndex = 5;
            this.btnSearchProducts.Text = "Search Products";
            this.btnSearchProducts.UseVisualStyleBackColor = true;
            // 
            // btnPayment
            // 
            this.btnPayment.Location = new System.Drawing.Point(409, 123);
            this.btnPayment.Name = "btnPayment";
            this.btnPayment.Size = new System.Drawing.Size(133, 48);
            this.btnPayment.TabIndex = 6;
            this.btnPayment.Text = "Make Payment";
            this.btnPayment.UseVisualStyleBackColor = true;
            // 
            // frHomepage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnPayment);
            this.Controls.Add(this.btnSearchProducts);
            this.Controls.Add(this.btnViewSchedule);
            this.Controls.Add(this.btnModifyApt);
            this.Controls.Add(this.btnViewApt);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnBook);
            this.Name = "frHomepage";
            this.Text = "Pick Action";
            this.Load += new System.EventHandler(this.frHomepage_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnBook;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnViewApt;
        private System.Windows.Forms.Button btnModifyApt;
        private System.Windows.Forms.Button btnViewSchedule;
        private System.Windows.Forms.Button btnSearchProducts;
        private System.Windows.Forms.Button btnPayment;
    }
}

